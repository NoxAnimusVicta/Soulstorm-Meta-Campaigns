"""Shared Subsector rules engine. Readiness is recorded separately from game balance.
Run python shared_sim.py --seeds 4 --cycles 18 --out shared-results
"""
from dataclasses import dataclass
from itertools import combinations, product
from pathlib import Path
import argparse, copy, hashlib, json, math, random
from balance_sim import State, Fleet, World, Project, legal, apply, fleet_losses
from construction_rules import PLANETARY, CATALOG, active, magnitude, legal_construction, construct, DEFENSIVE
from battle_setup import BattleSide, setup as soulstorm_setup

class PendingBattle(Exception):
    def __init__(self,setup):
        self.setup=setup
        super().__init__('Awaiting reported Soulstorm battle result')

class PendingAllocation(Exception):
    def __init__(self,point,candidates):
        self.point=point;self.candidates=candidates
        super().__init__('Attacker must choose tied Major fleet damage allocation')

@dataclass
class Holding:
    tier: int
    defence: int
    maximum: int
    system: int
    owner: int
    attacked: bool = False
    defended: bool = False
    station: bool = False
    capacity_bonus: int = 0

class SharedState(State):
    role='major'
    alignment='Independent'

    def afford(self,supply=0,manpower=0):
        # Voluntary expenditure must leave every spent resource above zero.
        return super().afford(supply,manpower) and (not supply or self.supply>supply) and (not manpower or self.manpower>manpower)

    def change(self,resource,delta):
        if self.role=='minor':return
        super().change(resource,delta)

    def full_host(self,host):
        if isinstance(host,tuple):
            kind,i=host
            if kind=='system':return i in self.present_systems
            f=self.fleets[i];return f.strength>0 and f.strength==f.maximum
        return super().full_host(host)

    def host_system(self,host):
        if isinstance(host,tuple):return host[1] if host[0]=='system' else self.fleets[host[1]].system
        if host==-1:return next((f.system for f in self.fleets if f.mobile and f.strength>0),None)
        return self.worlds[host].system

    def hit_fleet(self,index,damage):
        before=self.fleets[index].strength
        super().hit_fleet(index,damage)
        self.hit_host(('fleet',index),min(before,damage))
        if self.fleets[index].strength==0:
            for p in self.projects:
                if p.host==('fleet',index):p.integrity=0

    def hit_host(self,host,damage):
        for project in self.projects:
            if project.host!=host or project.integrity<=0:continue
            # Completed strength conversions remain part of the fleet.
            # An unfinished upgrade can lose only its new progress.
            floor=getattr(project,'permanent_integrity',0)
            project.integrity=max(floor,project.integrity-damage)

    def yards(self):
        built={self.host_system(p.host) for p in self.projects if p.profile in ('shipyard','grand_shipyard') and p.active}
        return self.established_yards | built | {f.system for f in self.fleets if f.mobile and f.strength>0}

    def income(self):
        si=mi=sum(w.tier for w in self.worlds if w.owned)+4*sum(f.mobile and f.strength>0 for f in self.fleets)
        for p in self.projects:
            if p.active:
                income={'depot':(2,0),'training':(0,2),'forge':(5,0),'academy':(0,5)}.get(p.profile,(0,0))
                factor=2 if p.effective_upgraded else 1;si+=income[0]*factor;mi+=income[1]*factor
        if self.trait=='war_economy':si+=3
        if self.trait=='martial':mi+=5
        return si,mi,sum(f.strength>0 and not f.mobile for f in self.fleets)

    def creation_strength(self,system):
        result=3 if self.trait=='swift' else 1
        for p in self.projects:
            if p.profile!='grand_shipyard' or not p.active:continue
            location=self.host_system(p.host)
            if location==system:result=max(result,5 if p.effective_upgraded else 3)
        return result

class Arena:
    def __init__(self, start=20, expand_mp=1, create_mp=1, rotation=0):
        self.players=[SharedState(supply=start,manpower=start,trait=t,expand_mp=expand_mp,create_mp=create_mp) for t in ('siege','efficient','mobile')]
        self.holdings=[Holding(4,12,12,0,0),Holding(2,4,4,0,0),Holding(4,12,12,1,1),Holding(2,4,4,1,1),Holding(2,4,4,2,2),Holding(1,2,2,2,2)]
        self.players[0].fleets=[Fleet(5,system=0),Fleet(5,system=0)]
        self.players[1].fleets=[Fleet(5,system=1),Fleet(5,system=1)]
        self.players[2].fleets=[Fleet(12,12,2,mobile=True),Fleet(5,system=2)]
        self.cycle=0;self.event=0;self.log=[];self.stop='';self.rotation=rotation
        self.defender_supply_cost=True
        self.capitals=[0,2,-1];self.provisional=[None,None,None]
        self.eliminated=set();self.mobile_loss_handled=set()
        self.mobile_defended=set()
        self.mobile_attacked=set();self.last_closed=-1
        self.fleet_combat=set();self.engaged_factions=set()
        self.alliances=set();self.consents=set();self.defensive_consents=set();self.turn_order=list(range(len(self.players)))
        self.phase_spent=set();self.phase_position={};self.begun_turns=set()
        self.defence_choices={};self.defender_policies={}
        self.human_players=set();self.reported_outcomes={}
        self.intel_choices={}
        self.planetfall_choices={}
        self.messages=[];self.pacts={}
        self.raid_profile={'strength':5,'supply':20,'manpower':20,'provisional':True};self.transit_consents=set()
        for p in range(3):self.refresh(p)

    def refresh(self,p):
        s=self.players[p]
        s.worlds=[World(w.tier,w.defence,w.maximum,w.system,w.owner==p,w.attacked) for w in self.holdings]
        s.event=self.event;s.cycle=self.cycle
        c=self.capitals[p]
        s.established_yards={self.holdings[c].system} if c is not None and c>=0 and self.holdings[c].owner==p else set()
        s.capital_hosts={c} if c is not None else set()
        s.present_systems={w.system for w in s.worlds if w.owned}|{f.system for f in s.fleets if f.strength>0}

    @property
    def systems(self):return sorted({w.system for w in self.holdings}|{f.system for s in self.players for f in s.fleets})

    def allied(self,p,q):
        alignment=self.players[p].alignment
        return p==q or frozenset((p,q)) in self.alliances or (alignment!='Independent' and alignment==self.players[q].alignment)

    def may_attack(self,p,q):
        return not self.allied(p,q) and self.pacts.get(frozenset((p,q)),-1)<self.cycle

    def propose_pact(self,p,q,through_cycle,rng):
        if type(through_cycle) is not int or through_cycle<self.cycle:raise ValueError('Pact expiry must be current or later Cycle')
        self.submit(p,'social',('communique',q,'Offer ceasefire through Cycle '+str(through_cycle)),rng)
        message=self.messages[-1];message['pact_until']=through_cycle
        return len(self.messages)-1

    def answer_pact(self,q,message_id,accept):
        if type(accept) is not bool:raise ValueError('Explicit acceptance or rejection required')
        message=self.messages[message_id]
        if 'pact_until' not in message:raise ValueError('No pact offer')
        self.reply(q,message_id,'Accepted' if accept else 'Rejected')
        if accept:self.pacts[frozenset((q,message['sender']))]=message['pact_until']
        self.log.append(dict(cycle=self.cycle,action='pact_decision',player=q,accepted=accept,through_cycle=message['pact_until']))

    def void(self,p,system):
        friendly=sum(self.strength(q,system) for q in range(len(self.players)) if self.allied(p,q))
        hostile=sum(self.strength(q,system) for q in range(len(self.players)) if not self.allied(p,q))
        return friendly>hostile

    def fleet_effect(self,p,group,name,base=1):
        return sum(magnitude(self.players[q],('fleet',i),name,base) for q,i in (self.fleet_ref(p,x) for x in group) if self.players[q].fleets[i].strength>0)

    def fleet_ref(self,p,reference):return reference if isinstance(reference,tuple) else (p,reference)

    def fleet_signature(self,p,reference,anchor=None):
        owner,i=self.fleet_ref(p,reference);state=self.players[owner];fleet=state.fleets[i]
        projects=tuple(sorted(tuple(sorted((k,repr(v)) for k,v in vars(pr).items() if k!='host')) for pr in state.projects if pr.host==('fleet',i) and pr.integrity>0))
        return owner,tuple(sorted((k,repr(v)) for k,v in vars(fleet).items())),projects,reference==anchor

    def fleet_buckets(self,p,here,anchor=None):
        buckets={}
        for reference in here:buckets.setdefault(self.fleet_signature(p,reference,anchor),[]).append(reference)
        return list(buckets.values())

    def representative_groups(self,p,here,anchor=None):
        buckets=self.fleet_buckets(p,here,anchor)
        groups=[tuple(ref for bucket,count in zip(buckets,counts) for ref in bucket[:count]) for counts in product(*(range(len(bucket)+1) for bucket in buckets)) if any(counts)]
        return sorted(groups,key=lambda g:(len(g),repr(g)))

    def canonical_order(self,p,order,anchor=None):
        if order[0]=='scout_attack':
            _,i,destination,attack=order
            projected=copy.deepcopy(self,{id(self.log):[]})
            projected.players[p].fleets[i].system=destination
            return (*order[:3],projected.canonical_order(p,attack,anchor=i))
        if order[0] not in ('naval','ground','ground_mobile','bombard_shared','structure_assault'):return order
        group=order[1]
        refs=[self.fleet_ref(p,x) for x in group]
        if not refs or len(set(refs))!=len(refs):raise ValueError('Empty or repeated fleet participant')
        system=self.players[refs[0][0]].fleets[refs[0][1]].system
        here=[i for i,f in enumerate(self.players[p].fleets) if f.strength>0 and not f.used and f.system==system]
        here.extend((q,i) for q,i,b in sorted(self.consents) if b==p and self.allied(p,q) and self.players[q].fleets[i].strength>0 and not self.players[q].fleets[i].used and self.players[q].fleets[i].system==system)
        if any(ref not in here for ref in group):raise ValueError('Participant unavailable or unapproved')
        selected=[]
        for bucket in self.fleet_buckets(p,here,anchor):selected.extend(bucket[:sum(ref in group for ref in bucket)])
        return (order[0],tuple(selected),*order[2:])

    def participating_strength(self,p,group):
        return sum(self.players[q].fleets[i].strength for q,i in (self.fleet_ref(p,x) for x in group))

    def grant_support(self,owner,beneficiary,indices):
        if owner==beneficiary or not self.allied(owner,beneficiary):raise ValueError('Support requires distinct allied factions')
        for fi in indices:
            fleet=self.players[owner].fleets[fi]
            if fleet.strength<=0 or fleet.used:raise ValueError('Fleet action unavailable for support')
        self.consents.update((owner,fi,beneficiary) for fi in indices)

    def grant_defence(self,owner,beneficiary,indices):
        """Explicit defensive support; already-used fleets remain eligible."""
        if owner==beneficiary or not self.allied(owner,beneficiary):raise ValueError('Defence requires allied factions')
        for fi in indices:
            if self.players[owner].fleets[fi].strength<=0:raise ValueError('Destroyed fleet cannot defend')
        self.defensive_consents.update((owner,fi,beneficiary) for fi in indices)

    def defenders(self,p,system):
        refs={(p,i) for i,f in enumerate(self.players[p].fleets) if f.strength>0 and f.system==system}
        refs.update((q,i) for q,i,beneficiary in self.defensive_consents if beneficiary==p and self.allied(p,q) and self.players[q].fleets[i].strength>0 and self.players[q].fleets[i].system==system)
        return tuple(sorted(refs))

    def engage(self,p,group,spend=False):
        for owner,i in (self.fleet_ref(p,x) for x in group):
            f=self.players[owner].fleets[i]
            if spend:f.used=True
            self.fleet_combat.add((owner,i));self.engaged_factions.add(owner)
            if f.mobile:self.mobile_attacked.add(owner)

    def initiation(self,p,group):
        refs=[self.fleet_ref(p,x) for x in group]
        owner,i=max((r for r in refs if self.players[r[0]].fleets[r[1]].strength>1),key=lambda r:(not self.players[r[0]].fleets[r[1]].mobile,self.players[r[0]].fleets[r[1]].strength,-r[0],-r[1]))
        self.players[owner].fleets[i].strength-=1

    def hurt_group(self,p,group,damage):
        for owner,i in (self.fleet_ref(p,x) for x in group):
            if damage and self.players[owner].fleets[i].mobile:self.mobile_attacked.add(owner)
            self.players[owner].hit_fleet(i,damage)

    def ground_strength(self,p,group):
        return self.participating_strength(p,group)+self.fleet_effect(p,group,'assault_boats',2)+self.fleet_effect(p,group,'carrier',5)

    def assault_affordable(self,p,group,defender,host,tier):
        damage=magnitude(self.players[defender],host,'orbital_cannons')
        projected=self
        if damage:
            projected=copy.deepcopy(self)
            owner,fi=max((self.fleet_ref(p,x) for x in group),key=lambda ref:self.players[ref[0]].fleets[ref[1]].strength)
            projected.players[owner].hit_fleet(fi,damage)
        if projected.participating_strength(p,group)==0:return True
        return projected.ground_strength(p,group)>=5 and projected.players[p].afford(tier,projected.ground_strength(p,group)//5)

    def commit_owned(self,p):
        for w,v in zip(self.holdings,self.players[p].worlds):
            if w.owner==p:w.defence=v.defence

    def strength(self,p,system):
        return sum(f.strength for f in self.players[p].fleets if f.system==system)

    def minor_resources(self,wi):
        w=self.holdings[wi]
        if self.players[w.owner].role!='minor':raise ValueError('Not a Minor holding')
        value=5*sum(h.tier for h in self.holdings if h.owner==w.owner)*(2 if getattr(self.players[w.owner],'prize',False) else 1)
        return value,value

    def add_minor(self,worlds,alignment='Independent',prize=False):
        """Add static holdings (tier, defence, maximum, system, station)."""
        if not worlds or any(w[0] not in (1,2,3,4) for w in worlds):raise ValueError('Invalid Minor holdings')
        p=len(self.players);s=SharedState(trait='none');s.role='minor';s.alignment=alignment;s.prize=prize or any(w[0]==4 for w in worlds)
        s.fleets=[];self.players.append(s);self.capitals.append(None);self.provisional.append(None)
        for tier,defence,maximum,system,station in worlds:
            self.holdings.append(Holding(tier,defence,maximum,system,p,station=station))
        for system in sorted({w[3] for w in worlds}):
            remaining=math.ceil(sum(w[2] for w in worlds if w[3]==system)/(1 if s.prize else 2))
            while remaining:
                strength=min(5,remaining);s.fleets.append(Fleet(strength,strength,system));remaining-=strength
        self.refresh(p)
        return p

    def storm_protected(self,p,system):
        return any(active(other,('system',system),'storm_transit') and (p==q or (q,p) in self.transit_consents and self.allied(p,q)) for q,other in enumerate(self.players))

    def bombard_damage(self,p,group):
        return max(1,self.participating_strength(p,group)//5)

    def bombard_cost(self,p,group,wi):
        # Cannons fire before calculating the strike and its ammunition cost.
        projected=self
        damage=magnitude(self.players[self.holdings[wi].owner],wi,'orbital_cannons')
        if damage:
            projected=copy.deepcopy(self)
            q,i=max((self.fleet_ref(p,x) for x in group),key=lambda ref:self.players[ref[0]].fleets[ref[1]].strength)
            projected.players[q].hit_fleet(i,damage)
        return 2*self.holdings[wi].tier+projected.bombard_damage(p,group)

    def opening(self,rng):
        self.cycle+=1
        self.mobile_attacked.clear()
        self.fleet_combat.clear();self.engaged_factions.clear();self.consents.clear();self.defensive_consents.clear()
        self.phase_spent.clear();self.phase_position.clear();self.begun_turns.clear()
        for w in self.holdings:w.attacked=False
        # One shared event roll, after every player's Logistics. No player turn intervenes.
        for p,s in enumerate(self.players):
            if p in self.eliminated:continue
            self.refresh(p)
            s.fleet_battled.clear()
            for f in s.fleets:f.used=False
            if self.cycle%3==0 and s.role=='major':
                si,mi,up=s.income();s.change('supply',si);s.change('manpower',mi)
                s.change('supply',-up);s.change('manpower',-up)
                self.log.append(dict(cycle=self.cycle,player=p,action='logistics',income=[si,mi],upkeep=up))
                if s.trait=='endurance':
                    for f in s.fleets:
                        if f.strength>0:f.strength=min(f.maximum,f.strength+1)
        check=rng.randint(1,6);self.event=rng.randint(1,6) if check in (1,6) else 0
        self.log.append(dict(cycle=self.cycle,action='event',check=check,table=self.event))
        for p,s in enumerate(self.players):
            if p in self.eliminated:continue
            s.event=self.event
            if self.event==1:
                for i,f in enumerate(s.fleets):
                    if f.strength and not self.storm_protected(p,f.system):s.hit_fleet(i,1)
            elif self.event in (3,4):
                for r in ('supply','manpower'):s.change(r,-5 if self.event==3 else 5)
        self.check()

    def turns(self,after=None):
        order=self.turn_order[self.rotation:]+self.turn_order[:self.rotation]
        visited=set(order[:order.index(after)+1]) if after is not None else set()
        while True:
            order=self.turn_order[self.rotation:]+self.turn_order[:self.rotation]
            remaining=[p for p in order if p not in visited]
            if not remaining:return
            p=remaining[0];visited.add(p)
            if p not in self.eliminated:yield p

    def begin_turn(self,p):
        if p in self.begun_turns:return
        self.begun_turns.add(p)
        self.mobile_defended.discard(p)
        for w in self.holdings:
            if w.owner==p:w.defended=False
        self.refresh(p)

    def closing(self):
        if self.last_closed==self.cycle:raise ValueError('Cycle already closed')
        self.last_closed=self.cycle
        # Snapshot active emplacements before applying simultaneous system fire.
        system_fire=[]
        for q,s in enumerate(self.players):
            for fi,f in enumerate(s.fleets):
                damage=sum(magnitude(other,('system',f.system),'system_defence') for p,other in enumerate(self.players) if self.may_attack(p,q))
                if f.strength and damage:system_fire.append((q,fi,damage))
        for q,fi,damage in system_fire:self.players[q].hit_fleet(fi,damage)
        self.check()
        for wi,w in enumerate(self.holdings):
            if w.attacked:continue
            s=self.players[w.owner]
            regen=magnitude(s,wi,'automated_defences')+magnitude(s,wi,'regenerative_fortifications',2)
            if s.role=='minor':regen+=1
            regen+=sum(magnitude(other,('system',w.system),'logistics_anchorage') for q,other in enumerate(self.players) if self.allied(w.owner,q))
            if regen:w.defence=min(w.maximum,w.defence+regen)
        for p,s in enumerate(self.players):
            if s.role=='minor' and p not in self.engaged_factions:
                eligible=[f for f in s.fleets if 0<f.strength<f.maximum]
                if eligible:max(eligible,key=lambda f:f.strength).strength+=1
            for i,f in enumerate(s.fleets):
                if not f.strength:continue
                repair=sum(magnitude(other,('system',f.system),'system_repair') for q,other in enumerate(self.players) if self.allied(p,q))
                if (p,i) not in self.fleet_combat:repair+=magnitude(s,('fleet',i),'repair_tender')
                f.strength=min(f.maximum,f.strength+repair)
            if p in self.mobile_attacked:continue
            regen=magnitude(s,-1,'automated_defences')+magnitude(s,-1,'regenerative_fortifications',2)
            for f in s.fleets:
                if f.mobile and f.strength>0 and regen:f.strength=min(f.maximum,f.strength+regen)
        self.check()

    def actions(self,p,phase,allow_scout=True,search=False,anchor=None):
        self.refresh(p);s=self.players[p]
        if self.stop or p in self.eliminated or s.role=='minor':return [('none',)]
        if phase=='social':
            options=[('none',)]
            for q in range(len(self.players)):
                if q==p or q in self.eliminated:continue
                self.refresh(q)
                if s.present_systems & self.players[q].present_systems:options.append(('communique',q,'Request a diplomatic exchange.'))
            return options
        if phase=='faction' and self.capitals[p] is None:
            # User ruling, 16 September: establish capital before rationing.
            host=self.provisional[p]
            return [('establish',i) for i,w in enumerate(self.holdings) if w.owner==p and not w.station and (host is None or i==host)] or [('none',)]
        if phase=='construction':return legal_construction(s)
        if phase=='faction':
            options=legal(s,phase)
            options.extend(('defend',i) for i,w in enumerate(self.holdings) if w.owner==p and w.defence==w.maximum and s.afford(w.tier,w.tier))
            if any(f.mobile and f.strength==f.maximum and f.strength>0 for f in s.fleets) and s.afford(4,4):options.append(('defend',-1))
            if not s.deficits:
                controlled=[system for system in self.systems if any(w.system==system and not w.station for w in self.holdings) and all(w.owner==p for w in self.holdings if w.system==system and not w.station)]
                if len(controlled)>=2 and s.afford(10,10):
                    for system in controlled:
                        if self.void(p,system):
                            options.extend(('summon',system,wi,trait) for wi,w in enumerate(self.holdings) if w.system==system and w.owner==p and not w.station for trait in ('war_economy','martial','efficient','salvagers','void','swift','endurance','siege','dread','fortification','industrial'))
                for ri,recipient in enumerate(self.holdings):
                    if recipient.owner!=p or recipient.defence==recipient.maximum:continue
                    plan=[];remaining=recipient.maximum-recipient.defence
                    for di,donor in enumerate(self.holdings):
                        if donor.owner!=p or di==ri or donor.system!=recipient.system or donor.defence<=1:continue
                        if donor.defence!=donor.maximum and not active(s,ri,'landing_zones'):continue
                        for amount in range(1,min(donor.defence-1,recipient.maximum-recipient.defence)+1):
                            options.append(('garrison',((di,ri,amount),)))
                        amount=min(donor.defence-1,remaining)
                        if amount:plan.append((di,ri,amount));remaining-=amount
                    if len(plan)>1:options.append(('garrison',tuple(plan)))
                for i,project in enumerate(s.projects):
                    cost=1 if CATALOG[project.profile].stages==3 else 3
                    if project.completed and 0<project.integrity<project.maximum and s.full_host(project.host) and s.afford(cost,cost):options.append(('defend_structure',i))
            return options
        if phase!='fleet':return legal(s,phase)
        actions=[('none',)]
        available=[i for i,f in enumerate(s.fleets) if f.strength>0 and not f.used]
        for i in available:
            f=s.fleets[i]
            if not f.mobile:
                actions.extend(('merge',i,j) for j,other in enumerate(s.fleets) if j!=i and not other.mobile and other.strength>0 and other.system==f.system)
            scuttle_safe=('manpower' in s.deficits or s.manpower>(5 if f.mobile else 1)) and (not f.mobile or 'supply' in s.deficits or s.supply>4)
            if self.void(p,f.system) and scuttle_safe:actions.append(('scuttle',i))
            if not f.mobile and self.void(p,f.system):
                for j,recipient in enumerate(s.fleets):
                    if i==j or recipient.mobile or recipient.strength<=0 or recipient.system!=f.system:continue
                    actions.extend(('transfer',i,j,n) for n in range(1,min(f.strength-1,recipient.maximum-recipient.strength)+1))
                    actions.extend(('transfer',i,j,-n) for n in range(1,min(recipient.strength-1,f.maximum-f.strength)+1))
            if not f.mobile and f.strength<f.maximum and f.system in s.yards() and s.afford(0 if s.trait=='void' else 1,s.expand_mp):actions.append(('expand',i))
            if self.event!=1 or self.storm_protected(p,f.system):
                actions.extend(('move',i,k) for k in self.systems if k!=f.system)
                if allow_scout and active(s,('fleet',i),'scout'):
                    for destination in self.systems:
                        if destination==f.system:continue
                        hypothetical=copy.deepcopy(self)
                        hypothetical.players[p].fleets[i].system=destination
                        for attack in hypothetical.actions(p,'fleet',allow_scout=False,search=search,anchor=i):
                            if attack[0] in ('ground','ground_mobile','bombard_shared') and i in attack[1]:
                                actions.append(('scout_attack',i,destination,attack))
        for system in self.systems:
            here=[i for i in available if s.fleets[i].system==system]
            here.extend((q,fi) for q,fi,beneficiary in sorted(self.consents) if beneficiary==p and self.allied(p,q) and self.players[q].fleets[fi].strength>0 and not self.players[q].fleets[fi].used and self.players[q].fleets[fi].system==system)
            groups=self.representative_groups(p,here,anchor) if search else [g for n in range(1,len(here)+1) for g in combinations(here,n)]
            hostile=[q for q in range(len(self.players)) if not self.allied(p,q) and self.strength(q,system)>0]
            for group in groups:
                fs=self.ground_strength(p,group);damage=max(1,fs//5)
                for q,d in enumerate(self.players):
                    if not self.may_attack(p,q):continue
                    for pi,project in enumerate(d.projects):
                        if project.integrity<=0 or d.host_system(project.host)!=system:continue
                        if project.completed and getattr(project,'permanent_integrity',0):continue
                        guarded=bool(self.defenders(q,system))
                        if (guarded and system not in s.fleet_battled and any(self.players[o].fleets[i].strength>1 for o,i in (self.fleet_ref(p,x) for x in group))) or (not hostile and s.afford(2)):
                            actions.append(('structure_assault',group,q,pi))
                if system not in s.fleet_battled and any(self.players[o].fleets[i].strength>1 for o,i in (self.fleet_ref(p,x) for x in group)):
                    actions.extend(('naval',group,system,q) for q in hostile if self.may_attack(p,q))
                for q in hostile:
                    if not self.may_attack(p,q):continue
                    for fi,f in enumerate(self.players[q].fleets):
                        if f.mobile and f.strength>0 and f.system==system and self.assault_affordable(p,group,q,-1,4):
                            actions.append(('ground_mobile',group,q,fi))
                for wi,w in enumerate(self.holdings):
                    if w.system!=system or not self.may_attack(p,w.owner):continue
                    if not hostile and w.defence>1 and s.afford(self.bombard_cost(p,group,wi)):actions.append(('bombard_shared',group,wi))
                    if self.assault_affordable(p,group,w.owner,wi,w.tier):actions.append(('ground',group,wi))
        return actions

    def submit(self,p,phase,a,rng,forced=None):
        """Validated public turn entry point; act remains a hypothetical resolver."""
        phases={'fleet':2,'faction':3,'social':4,'construction':5}
        if phase not in phases:raise ValueError('Unknown phase')
        if p in self.eliminated or self.players[p].role=='minor':raise ValueError('No active Major turn')
        if phases[phase]<self.phase_position.get(p,2):raise ValueError('Cannot return to an earlier phase')
        if (p,phase) in self.phase_spent:raise ValueError('Phase action already spent')
        options=self.actions(p,phase,search=True)
        if phase=='fleet' and a not in options and self.canonical_order(p,a) in options:options.append(a)
        if a[0]=='communique' and phase=='social':
            if not isinstance(a[2],str) or not a[2].strip():raise ValueError('Communique requires a message')
            if not any(x[0]=='communique' and x[1]==a[1] for x in options):raise ValueError('No shared system presence')
            options=options+[a]
        if a[0]=='garrison' and phase=='faction' and self.capitals[p] is not None and not self.players[p].deficits:
            self.validate_garrison(p,a[1])
        elif a not in options:raise ValueError('Illegal order for current phase and state')
        checkpoint=copy.deepcopy(self.__dict__)
        random_state=rng.getstate() if hasattr(rng,'getstate') else None
        try:self.act(p,a,rng,forced,_validated=True)
        except Exception:
            self.__dict__.clear();self.__dict__.update(checkpoint)
            if random_state is not None:rng.setstate(random_state)
            raise
        self.phase_position[p]=phases[phase]
        if phase!='fleet' or a[0]=='none':self.phase_spent.add((p,phase))

    def reply(self,recipient,message_id,text):
        message=self.messages[message_id]
        if message['recipient']!=recipient or message['cycle']!=self.cycle or message['reply'] is not None:raise ValueError('Reply unavailable')
        if not isinstance(text,str) or not text.strip():raise ValueError('Reply requires text')
        message['reply']=text
        self.log.append(dict(cycle=self.cycle,action='communique_reply',player=recipient,message_id=message_id))

    def validate_garrison(self,p,transfers):
        if not transfers:raise ValueError('Empty Garrison Transfer')
        totals={};outgoing={}
        for di,ri,amount in transfers:
            donor=self.holdings[di];recipient=self.holdings[ri]
            if di==ri or not isinstance(amount,int) or amount<=0:raise ValueError('Invalid garrison amount')
            if donor.owner!=p or recipient.owner!=p or donor.system!=recipient.system:raise ValueError('Garrison requires own holdings in the same system')
            if donor.defence!=donor.maximum and not active(self.players[p],ri,'landing_zones'):raise ValueError('Donor not fully defended')
            outgoing[di]=outgoing.get(di,0)+amount
            totals[di]=totals.get(di,0)-amount;totals[ri]=totals.get(ri,0)+amount
        for di,amount in outgoing.items():
            if self.holdings[di].defence-amount<1:raise ValueError('Donor must retain one defence')
        for wi,delta in totals.items():
            if not 1<=self.holdings[wi].defence+delta<=self.holdings[wi].maximum:raise ValueError('Garrison capacity exceeded')
        return totals

    def act(self,p,a,rng,forced=None,_validated=False):
        if a[0]=='none':return
        self.refresh(p);s=self.players[p];kind=a[0]
        self.log.append(dict(cycle=self.cycle,player=p,action=kind,order=a))
        if kind=='summon':
            if not _validated and a not in self.actions(p,'faction'):raise ValueError('Illegal Summon Allies')
            _,system,capital,trait=a;s.pay(10,10)
            ally=SharedState(supply=10,manpower=10,trait=trait,expand_mp=1);ally.alignment=s.alignment;ally.fleets=[];ally.policy_parent=p
            q=len(self.players);self.defender_policies[q]=self.defender_policies.get(p,'balanced');self.players.append(ally);self.capitals.append(None);self.provisional.append(capital)
            granted={wi for wi,w in enumerate(self.holdings) if w.system==system and not w.station and w.owner==p}
            for wi in granted:self.holdings[wi].owner=q;self.holdings[wi].defended=False
            for project in list(s.projects):
                if isinstance(project.host,int) and project.host in granted:s.projects.remove(project);ally.projects.append(project)
            if self.capitals[p] in granted:self.capitals[p]=None
            self.alliances.add(frozenset((p,q)));self.turn_order.insert(self.turn_order.index(p)+1,q)
            self.log.append(dict(cycle=self.cycle,action='ally_summoned',player=p,ally=q,system=system,provisional_capital=capital))
            self.check();return
        if kind=='communique':
            self.messages.append(dict(sender=p,recipient=a[1],text=a[2],reply=None,cycle=self.cycle))
            return
        if kind=='garrison':
            for wi,delta in self.validate_garrison(p,a[1]).items():self.holdings[wi].defence+=delta
            self.check();return
        if kind=='merge':
            if not _validated and a not in self.actions(p,'fleet',search=True):raise ValueError('Illegal Fleet Merge')
            _,survivor,absorbed=a;target=s.fleets[survivor];donor=s.fleets[absorbed]
            bonus=max(0,donor.maximum-5)
            target.maximum+=bonus;target.strength=min(target.maximum,target.strength+donor.strength)
            target.used=True;donor.strength=0
            for project in s.projects:
                if project.host==('fleet',absorbed):project.host=('fleet',survivor)
            self.check();return
        if kind=='transfer':
            if not _validated and a not in self.actions(p,'fleet',search=True):raise ValueError('Illegal Fleet Transfer')
            _,donor,recipient,amount=a
            s.fleets[donor].strength-=amount;s.fleets[recipient].strength+=amount
            s.fleets[donor].used=True
            self.check();return
        if kind=='scuttle':
            if not _validated and a not in self.actions(p,'fleet',search=True):raise ValueError('Illegal Scuttle')
            fi=a[1];refund=s.fleets[fi].strength//2;s.fleets[fi].used=True
            s.hit_fleet(fi,s.fleets[fi].strength)
            s.change('supply',refund)
            self.check();return
        if kind=='scout_attack':
            if not _validated and self.canonical_order(p,a) not in self.actions(p,'fleet',search=True):raise ValueError('Illegal Scout movement/attack')
            _,fi,destination,attack=a
            s.fleets[fi].system=destination
            self.act(p,attack,rng,forced,_validated=True)
            return
        if kind=='structure_assault':
            if not _validated and self.canonical_order(p,a) not in self.actions(p,'fleet',search=True):raise ValueError('Illegal Structure Assault')
            group,q,pi=a[1:];d=self.players[q];project=d.projects[pi]
            system=d.host_system(project.host)
            defenders=self.defenders(q,system)
            self.engage(p,group,spend=True)
            if defenders:
                s.fleet_battled.add(system)
                self.engage(q,defenders)
                self.initiation(p,group)
                rolls=forced or (rng.randint(1,6)+rng.randint(1,6),rng.randint(1,6)+rng.randint(1,6))
                margin=rolls[0]+self.participating_strength(p,group)+self.fleet_effect(p,group,'escort',3)-rolls[1]-self.participating_strength(q,defenders)-self.fleet_effect(q,defenders,'escort',3)-magnitude(d,('system',system),'defence_platform',5)
                if margin>0:project.integrity=max(getattr(project,'permanent_integrity',0),project.integrity-fleet_losses(margin))
                elif margin<0:self.hurt_group(p,group,fleet_losses(-margin))
                self.log.append(dict(cycle=self.cycle,combat='structure',attacker=p,defender=q,rolls=rolls,margin=margin))
                for owner in {p,q}|{o for o,i in [*(self.fleet_ref(p,x) for x in group),*defenders]}:
                    if self.players[owner].trait=='salvagers':self.players[owner].change('supply',1)
            else:
                s.pay(2)
                damage=max(1,self.participating_strength(p,group)//5)
                project.integrity=max(getattr(project,'permanent_integrity',0),project.integrity-damage)
            self.check();return
        if kind=='defend_structure':
            if not _validated and a not in self.actions(p,'faction'):raise ValueError('Illegal structure Defend')
            project=s.projects[a[1]];cost=1 if CATALOG[project.profile].stages==3 else 3
            s.pay(cost,cost)
            if not s.full_host(project.host) or project.integrity<=0:
                s.stop='Unresolved timing: structure Defend payment damaged host through deficit'
            else:project.integrity=min(project.maximum,project.integrity+cost)
            self.check();return
        if kind in ('start','build','repair','upgrade'):
            if not _validated and a not in self.actions(p,'construction'):raise ValueError('Illegal construction action')
            construct(s,a)
            project=s.projects[-1] if kind=='start' else s.projects[a[1]]
            if project.completed and project.integrity==project.maximum and project.profile in ('assault_cruiser','flagship'):
                f=s.fleets[project.host[1]]
                capacity=(2 if project.profile=='assault_cruiser' else 5)*(2 if project.upgraded else 1)
                extra=capacity-getattr(project,'granted_capacity',0)
                f.maximum+=extra;f.strength+=extra
                project.granted_capacity=capacity;project.permanent_integrity=project.maximum
            if project.active and project.profile=='consolidation':
                w=self.holdings[project.host]
                w.tier+=1;w.defence*=2;w.maximum*=2
                s.projects.remove(project)
                self.log.append(dict(cycle=self.cycle,player=p,action='consolidated',holding=project.host,tier=w.tier))
            elif project.active and project.profile=='void_station':
                system=s.host_system(project.host)
                self.holdings.append(Holding(1,2,2,system,p,station=True))
                s.projects.remove(project)
                self.log.append(dict(cycle=self.cycle,player=p,action='station_completed',holding=len(self.holdings)-1))
            self.check();return
        if kind=='establish':
            wi=a[1];w=self.holdings[wi];self.provisional[p]=wi
            w.maximum=min(12,w.maximum*2);w.defence=min(w.maximum,w.defence*2)
            if w.maximum==12:
                w.tier=4;self.capitals[p]=wi;self.provisional[p]=None
            self.check();return
        if kind not in ('naval','ground','ground_mobile','bombard_shared'):
            if kind=='expand':
                f=s.fleets[a[1]];f.used=True;s.pay(0 if s.trait=='void' else 1,s.expand_mp)
                if f.strength:f.strength=min(f.maximum,f.strength+2)
                self.check();return
            creation_strength=s.creation_strength(a[1]) if kind=='create' else None
            if kind=='defend' and a[1]==-1:
                s.pay(4,4)
                for f in s.fleets:
                    if f.mobile and f.strength:f.strength=min(f.maximum,f.strength+4)
            else:apply(s,a,rng)
            self.commit_owned(p)
            if creation_strength is not None:s.fleets[-1].strength=creation_strength
            if kind=='defend' and a[1]>=0:self.holdings[a[1]].defended=True
            if kind=='defend' and a[1]==-1:self.mobile_defended.add(p)
            if kind=='defend' and s.trait=='fortification':
                if a[1]>=0:
                    w=self.holdings[a[1]];w.defence=min(w.maximum,w.defence+2)
                else:
                    for f in s.fleets:
                        if f.mobile and f.strength:f.strength=min(f.maximum,f.strength+2)
            if kind=='defend' and s.trait=='fortification':
                self.refresh(p)
                if s.full_host(a[1]):
                    eligible=[pr for pr in s.projects if pr.host==a[1] and pr.profile in DEFENSIVE and pr.completed and 0<pr.integrity<pr.maximum]
                    if eligible:
                        pr=min(eligible,key=lambda pr:pr.maximum-pr.integrity)
                        pr.integrity+=1
                        self.log.append(dict(cycle=self.cycle,player=p,action='fortification_repair',profile=pr.profile,integrity=pr.integrity))
            self.check();return
        group=a[1]
        for owner,i in (self.fleet_ref(p,x) for x in group):self.players[owner].fleets[i].used=True
        if kind!='bombard_shared':
            participants=[self.fleet_ref(p,x) for x in group]
            self.engaged_factions.update(owner for owner,i in participants);self.fleet_combat.update(participants)
        if kind=='naval':
            system,q=a[2:];d=self.players[q]
            s.fleet_battled.add(system)
            defenders=self.defenders(q,system)
            self.engage(q,defenders)
            self.initiation(p,group)
            rolls=forced or (rng.randint(1,6)+rng.randint(1,6),rng.randint(1,6)+rng.randint(1,6))
            margin=rolls[0]+self.participating_strength(p,group)+self.fleet_effect(p,group,'escort',3)-rolls[1]-self.participating_strength(q,defenders)-self.fleet_effect(q,defenders,'escort',3)-magnitude(d,('system',system),'defence_platform',5)
            if margin>0:self.hurt_group(q,defenders,fleet_losses(margin))
            elif margin<0:self.hurt_group(p,group,fleet_losses(-margin))
            self.log.append(dict(cycle=self.cycle,combat='naval',attacker=p,defender=q,rolls=rolls,margin=margin))
            winners=group if margin>0 else defenders if margin<0 else ()
            winner=p if margin>0 else q
            for owner,i in (self.fleet_ref(winner,x) for x in winners):
                self.players[owner].change('supply',magnitude(self.players[owner],('fleet',i),'salvage_wing',3))
            for owner in {o for o,i in [*(self.fleet_ref(p,x) for x in group),*defenders]}:
                if self.players[owner].trait=='salvagers':self.players[owner].change('supply',1)
        else:
            mobile_target=kind=='ground_mobile'
            if mobile_target:
                q,fi=a[2:];d=self.players[q];target=d.fleets[fi];wi=-1
                self.mobile_attacked.add(q)
                w=Holding(4,target.strength,target.maximum,target.system,q,defended=q in self.mobile_defended)
            else:
                wi=a[2];w=self.holdings[wi];q=w.owner;d=self.players[q]
            shield_network=bool(active(d,wi,'planetary_shield'))
            shield_invulnerable=shield_network and self.void(q,w.system)
            cannon_damage=magnitude(d,wi,'orbital_cannons')
            if cannon_damage:
                target_owner,target_i=max((self.fleet_ref(p,x) for x in group),key=lambda ref:self.players[ref[0]].fleets[ref[1]].strength)
                self.players[target_owner].hit_fleet(target_i,cannon_damage)
                if self.players[target_owner].fleets[target_i].mobile:self.mobile_attacked.add(target_owner)
                self.log.append(dict(cycle=self.cycle,action='orbital_cannons',player=q,target_player=target_owner,target_fleet=target_i,damage=cannon_damage))
                if self.participating_strength(p,group)==0:
                    w.attacked=True;self.check();return
            base_damage=self.ground_strength(p,group)//5
            damage=base_damage+1+(1 if s.trait=='siege' else 0)+self.fleet_effect(p,group,'bombardment_bay')+self.fleet_effect(p,group,'siege_platform',2)
            human_battle=p in self.human_players or q in self.human_players
            intel=self.intel_choices.get(p) if self.event==6 and human_battle else None
            if intel not in (None,'difficulty','damage'):raise ValueError('Invalid Intel Breakthrough choice')
            if intel=='damage':damage+=1
            if kind=='bombard_shared':damage=max(1,self.participating_strength(p,group)//5)
            w.attacked=True
            if kind=='bombard_shared':
                s.pay(2*w.tier+damage);actual=min(w.defence-1,max(0,damage-magnitude(d,wi,'void_shield')))
            else:
                s.pay(w.tier,base_damage)
                self.engaged_factions.add(q)
                defenders=self.defenders(q,w.system)
                self.engage(q,defenders)
                # Inherited AI defender commitment convention; Supply ambiguity is a switch.
                militia=bool(active(d,wi,'militia'))
                commitment=0 if militia else damage if human_battle else damage//2
                defender_supply,defender_manpower=self.minor_resources(wi) if d.role=='minor' else (d.supply,d.manpower)
                isolated=not militia and ('manpower' in d.deficits or defender_manpower<commitment)
                conscription=self.defence_choices.pop((q,wi),None)
                if isolated and commitment and conscription is None and q in self.defender_policies and q not in self.human_players:
                    from bot_control import conscription as choose_conscription
                    conscription=choose_conscription(self,q,wi,commitment,damage)
                conscripted=False
                if isolated and commitment and conscription is not None:
                    if sum(amount for di,amount in conscription)!=commitment:raise ValueError('Conscription must meet the exact commitment')
                    if len({di for di,amount in conscription})!=len(conscription):raise ValueError('Duplicate conscription donor')
                    for di,amount in conscription:
                        donor=self.holdings[di]
                        if di==wi or donor.owner!=q or donor.defence!=donor.maximum or not isinstance(amount,int) or not 0<amount<donor.defence:
                            raise ValueError('Invalid conscription donor')
                    for di,amount in conscription:self.holdings[di].defence-=amount
                    isolated=False;conscripted=True
                    self.log.append(dict(cycle=self.cycle,player=q,action='forced_conscription',donors=conscription,commitment=commitment))
                if isolated:
                    commitment=0
                    self.log.append(dict(cycle=self.cycle,player=q,action='isolated_defense'))
                defender_supply_paid=min(defender_supply,w.tier) if self.defender_supply_cost else 0
                if defender_supply_paid:d.change('supply',-defender_supply_paid)
                if commitment and not conscripted:d.change('manpower',-commitment)
                if d.role=='major':defender_supply,defender_manpower=d.supply,d.manpower
                else:
                    defender_manpower-=commitment
                    defender_supply-=defender_supply_paid
                av=self.ground_strength(p,group)+s.supply//5+s.manpower//5+(4 if self.event==6 else 0)
                dv=self.participating_strength(q,defenders)+defender_supply//5+defender_manpower//5+(4 if self.event==2 else 0)+(4 if (w.defended or shield_network) and s.trait!='siege' else 0)-(8 if isolated else 0)+magnitude(d,wi,'bunker',4)
                raid_won=False
                if human_battle:
                    if (p,wi) not in self.reported_outcomes:
                        attacker=BattleSide(s.supply,s.manpower,self.ground_strength(p,group),str(p))
                        defender=BattleSide(defender_supply,defender_manpower,self.participating_strength(q,defenders),str(q))
                        attacking=p in self.human_players
                        setup=soulstorm_setup(attacker if attacking else defender,defender if attacking else attacker,
                            player_attacking=attacking,defended=w.defended or shield_network,
                            siege=s.trait=='siege',bunker_levels=magnitude(d,wi,'bunker'),
                            ambush=self.event==2,intel_difficulty=intel=='difficulty',isolated=isolated,
                            raider='Iron Warriors' if self.event==5 else None)
                        if self.event==6:setup['intel_choice_required']=intel is None;setup['intel_options']=['difficulty','damage'];setup['intel_choosing_faction']=p
                        raise PendingBattle(setup)
                    if self.event==6 and intel is None:raise ValueError('Choose Intel Breakthrough effect before resolving')
                    outcome=self.reported_outcomes.pop((p,wi))
                    raid_won=outcome=='raider' and self.event==5
                    if type(outcome) is not bool and not raid_won:raise ValueError('Reported outcome must identify attacker victory/defeat, or raider victory during a raid')
                    won=outcome is True
                    rolls=None
                else:
                    rolls=forced or (rng.randint(1,20),rng.randint(1,20));won=rolls[0]+av>rolls[1]+dv
                    if self.event==5:
                        raid_roll=forced[2] if forced and len(forced)>2 else rng.randint(1,20)
                        raid_total=raid_roll+13
                        totals=(rolls[0]+av,rolls[1]+dv,raid_total)
                        highest=max(totals);tied=totals.count(highest)>1
                        won=not tied and totals[0]==highest
                        raid_won=not tied and totals[2]==highest
                        self.log.append(dict(cycle=self.cycle,combat='third_party_raid',rolls=[rolls[0],rolls[1],raid_roll],totals=totals,winner='raider' if raid_won else 'attacker' if won else 'defender',provisional=True,profile=dict(self.raid_profile)))
                transport=max((magnitude(self.players[o],('fleet',i),'troop_transport',10) for o,i in (self.fleet_ref(p,x) for x in group) if self.players[o].fleets[i].strength>0),default=0)
                if won or (isolated and not raid_won):s.change('manpower',min(base_damage,math.floor(base_damage*.6)+transport//10))
                defence_return=.6 if not human_battle else .8
                if not won and not raid_won:d.change('manpower',math.floor(commitment*defence_return))
                if not won and not raid_won:d.change('supply',math.floor(defender_supply_paid*.8))
                actual=damage if won else (1 if s.trait=='siege' else 0)
                if raid_won:
                    if w.tier>=3:actual=max(actual,w.defence-w.defence//2)
                    actual=min(max(0,w.defence-1),actual)
                self.log.append(dict(cycle=self.cycle,combat='ground',attacker=p,defender=q,rolls=rolls,totals=None if human_battle else [rolls[0]+av,rolls[1]+dv],won=won,reported=human_battle))
                for owner in {p,q}|{o for o,i in [*(self.fleet_ref(p,x) for x in group),*defenders]}:
                    if self.players[owner].trait=='salvagers':self.players[owner].change('supply',1)
            if kind!='bombard_shared':actual=max(0,actual-magnitude(d,wi,'void_shield'))
            if shield_invulnerable:actual=0
            if mobile_target:
                d.hit_fleet(fi,actual)
                if target.strength==0 and kind!='bombard_shared':
                    # check() applies the Capital loss; replace ordinary Supply
                    # expenditure rather than charging both in the final ledger.
                    d.change('supply',defender_supply_paid)
                self.check();return
            d.hit_host(wi,min(w.defence,actual));w.defence-=actual
            if w.defence<=0:
                capital_lost=self.capitals[q]==wi
                penalty=4 if w.tier==4 else 2
                # Replace the already committed defender Supply with Planet Fall.
                d.change('supply',(defender_supply_paid if kind!='bombard_shared' else 0)-penalty);d.change('manpower',-penalty)
                w.defence=1;w.owner=p;w.defended=False;s.captures+=1
                if s.trait=='salvagers':s.change('supply',2)
                if capital_lost:self.capitals[q]=None
                if self.provisional[q]==wi:self.provisional[q]=None
                for project in list(d.projects):
                    if project.host==wi and project.integrity>0:d.projects.remove(project);s.projects.append(project)
                allocation=self.planetfall_choices.get((p,wi),())
                for point in range(actual):
                    eligible=[i for i,f in enumerate(d.fleets) if f.strength>0 and f.system==w.system]
                    if not eligible:break
                    strongest=max(d.fleets[i].strength for i in eligible)
                    tied=[i for i in eligible if d.fleets[i].strength==strongest]
                    if point<len(allocation):
                        i=allocation[point]
                        if i not in tied:raise ValueError('Planet Fall damage must hit a strongest surviving fleet')
                    else:
                        i=rng.choice(tied)
                        self.log.append(dict(cycle=self.cycle,action='planetfall_allocation',player=q,point=point,fleet=i,candidates=tied))
                    d.hit_fleet(i,1)
                if not any(h.owner==q for h in self.holdings) and not any(f.mobile and f.strength for f in d.fleets):
                    for i,f in enumerate(d.fleets):
                        if f.strength:d.hit_fleet(i,f.strength)
        self.check()

    def check(self):
        # Resolve mobile-capital loss once, including losses caused by deficits.
        for p,s in enumerate(self.players):
            if p not in self.mobile_loss_handled and any(f.mobile and f.strength==0 for f in s.fleets):
                self.mobile_loss_handled.add(p);self.capitals[p]=None;s.trait='none'
                if s.stop.startswith('Mobile Capital destroyed:'):s.stop=''
                s.change('supply',-4);s.change('manpower',-4)
                self.log.append(dict(cycle=self.cycle,player=p,action='mobile_capital_lost'))
            if p not in self.eliminated and not any(w.owner==p for w in self.holdings) and not any(f.mobile and f.strength for f in s.fleets):
                self.eliminated.add(p);self.capitals[p]=None
                for i,f in enumerate(s.fleets):
                    if f.strength:s.hit_fleet(i,f.strength)
                self.log.append(dict(cycle=self.cycle,player=p,action='eliminated'))
        # System structures change hands only when one faction owns every
        # planetary body and also has void superiority. Stations are excluded.
        for system in self.systems:
            owners={w.owner for w in self.holdings if w.system==system and not w.station}
            if len(owners)!=1:continue
            captor=next(iter(owners))
            if not self.void(captor,system):continue
            for q,other in enumerate(self.players):
                if self.allied(captor,q):continue
                for project in list(other.projects):
                    if project.host!=('system',system) or project.integrity<=0:continue
                    if CATALOG[project.profile].stages==3:
                        other.projects.remove(project);self.players[captor].projects.append(project)
                    else:project.integrity=0
                    self.log.append(dict(cycle=self.cycle,action='system_construction_control',player=captor,previous=q,profile=project.profile))
        for p,s in enumerate(self.players):
            for wi,w in enumerate(self.holdings):
                if w.owner!=p:continue
                bonus=magnitude(s,wi,'fortification_network',2)
                w.maximum+=bonus-w.capacity_bonus;w.capacity_bonus=bonus
                w.defence=min(w.defence,w.maximum)
            for f in s.fleets:
                if not f.mobile or f.strength<=0:continue
                bonus=magnitude(s,-1,'fortification_network',2)
                f.maximum+=bonus-getattr(f,'capacity_bonus',0);f.capacity_bonus=bonus
                f.strength=min(f.strength,f.maximum)
            self.refresh(p);s.validate()
            if s.stop:self.stop=s.stop
        assert all(w.owner in range(len(self.players)) for w in self.holdings)
        assert len(self.capitals)==len(self.provisional)==len(self.players)
        assert len(self.turn_order)==len(set(self.turn_order))
        for p,s in enumerate(self.players):
            capital=self.capitals[p]
            if capital is not None and capital>=0:
                assert self.holdings[capital].owner==p and not self.holdings[capital].station
            for project in s.projects:
                assert project.profile in CATALOG
                if project.integrity<=0:continue
                if isinstance(project.host,tuple):
                    kind,i=project.host
                    assert kind in ('fleet','system')
                    if kind=='fleet':assert 0<=i<len(s.fleets) and s.fleets[i].strength>0
                    else:assert i in self.systems
                elif project.host==-1:assert any(f.mobile and f.strength>0 for f in s.fleets)
                else:assert self.holdings[project.host].owner==p

def _copy_model(self,memo):
    """Copy mutable state without generic reconstruction of primitive fields."""
    result=type(self).__new__(type(self));memo[id(self)]=result
    result.__dict__={key:(value if type(value) in (str,int,float,bool,type(None)) else copy.deepcopy(value,memo)) for key,value in vars(self).items()}
    return result

for _model in (Arena,SharedState,Holding,Fleet,World,Project):
    _model.__deepcopy__=_copy_model

def search_clone(arena):
    # World lists are derived read-only caches: refresh() replaces an actor's
    # cache before every mutation and check() replaces all caches afterwards.
    memo={id(arena.log):[],id(arena.messages):[copy.deepcopy(m) for m in arena.messages if m['cycle']==arena.cycle]}
    for state in arena.players:
        memo[id(state.trace)]=[]
        memo[id(state.worlds)]=state.worlds
    return copy.deepcopy(arena,memo)

# Distinct tactical priorities, still heuristic bots, not validated human substitutes.
# Each compares sampled consequences and threat to its own holdings.
def policy_for(arena,p,policies):
    while p>=len(policies):p=getattr(arena.players[p],'policy_parent',0)
    return policies[p]

POLICY_WEIGHTS={
 'raider':(28,1.2,1.,1.,4.),
 'industrial':(14,1.2,3.,1.8,1.),
 'fleet_control':(18,2.,1.,1.4,1.),
 'conservative':(16,1.4,1.5,3.,1.),
 'opportunist':(30,1.2,1.,1.2,3.),
 'balanced':(20,1.4,2.,2.,2.),
}

def utility(arena,p,policy):
    s=arena.players[p];si,mi,up=s.income()
    capture_weight,naval,economy,caution,damage_weight=POLICY_WEIGHTS[policy]
    if p in arena.eliminated:return -10000
    score=2*math.sqrt(s.supply)+2*math.sqrt(s.manpower)-25*len(s.deficits)
    score+=8*sum(s.deficits.values())
    # Predict mandatory upkeep and keep a buffer for the next assault/event.
    reserve=max(3,up+2)
    score-=caution*(max(0,reserve-s.supply)+max(0,reserve-s.manpower))
    score+=capture_weight*sum(w.tier for w in arena.holdings if w.owner==p)
    score+=sum(f.strength for f in s.fleets)*naval
    # Logistics is a three-Cycle flow, not income received every turn.
    score+=economy*(si+mi-2*up)/3
    owned_systems={w.system for w in arena.holdings if w.owner==p}|{f.system for f in s.fleets if f.mobile and f.strength>0}
    desired_strength=5*(len(owned_systems)+1)
    actual_strength=sum(f.strength for f in s.fleets)
    score-=naval*max(0,desired_strength-actual_strength)
    # Repair access is a real strategic option. This rewards returning depleted
    # fleets to a yard rather than banking resources indefinitely at the front.
    for f in s.fleets:
        if f.strength>0 and not f.mobile and f.strength<f.maximum and f.system in s.yards():
            score+=naval*.8*(f.maximum-f.strength)
    score-=caution*(max(0,2*(up-si)-s.supply)+max(0,2*(up-mi)-s.manpower))
    for project in s.projects:
        if project.integrity>0:
            score+=project.integrity*(2 if policy=='industrial' else .5)
            if project.completed and not project.active:score-=3
    for system in arena.systems:
        own=arena.strength(p,system);enemy=sum(arena.strength(q,system) for q in range(len(arena.players)) if not arena.allied(p,q))
        holdings=[w for w in arena.holdings if w.system==system and w.owner==p]
        targets=[w for w in arena.holdings if w.system==system and arena.may_attack(p,w.owner)]
        score-=max(0,enemy-own)*(.7*caution if holdings else .1)
        score+=sum(w.defence*.35 for w in holdings)
        if targets:
            score+=sum(w.maximum-w.defence for w in targets)*damage_weight
            score+=min(own,enemy+10)*(.9 if policy in ('raider','opportunist') else .5)
            if policy=='fleet_control':score-=enemy*1.2
    # Alliances matter, but coalition assets never become the player's resources.
    score+=.35*sum(capture_weight*sum(w.tier for w in arena.holdings if w.owner==q)+naval*sum(f.strength for f in other.fleets) for q,other in enumerate(arena.players) if q!=p and arena.allied(p,q))
    if arena.stop:score-=10000
    return score

def choose(arena,p,phase,policy,decision):
    actions=arena.actions(p,phase,search=True)
    best=(-float('inf'),actions[0])
    rng=random.Random(900000+decision);draws=[tuple(rng.randint(1,20) for _ in range(3 if arena.event==5 else 2)) for _ in range(3)]
    naval_draws=[(rng.randint(1,6)+rng.randint(1,6),rng.randint(1,6)+rng.randint(1,6)) for _ in range(3)]
    for a in actions:
        scores=[]
        for roll in naval_draws if a[0] in ('naval','structure_assault') else draws if a[0] in ('ground','ground_mobile','scout_attack') else draws[:1]:
            t=search_clone(arena)
            t.act(p,a,random.Random(0),roll if a[0] in ('ground','ground_mobile','scout_attack') else roll[:2],_validated=True);scores.append(utility(t,p,policy))
        score=sum(scores)/len(scores)-.15*(max(scores)-min(scores))
        if score>best[0]+1e-9:best=(score,a)
    return best[1]

def run(seed,cycles=18,start=20,rotation=0,expand_mp=0,create_mp=1,planner_depth=0,policy_rotation=0):
    a=Arena(start,expand_mp,create_mp,rotation);events=random.Random(seed);combat=random.Random(seed+1000000)
    base=['raider','industrial','fleet_control'];policies=base[policy_rotation:]+base[:policy_rotation];decision=0
    a.defender_policies=dict(enumerate(policies))
    def select(p,phase):
        nonlocal decision
        if planner_depth:
            from strategic_planner import plan
            order=plan(a,p,phase,policies,decision,planner_depth)
        else:order=choose(a,p,phase,policy_for(a,p,policies),decision)
        decision+=1
        return order
    for _ in range(cycles):
        a.opening(events)
        if a.stop:break
        for p in a.turns():
            if p in a.eliminated:continue
            a.begin_turn(p)
            from bot_control import coordinate,social
            coordinate(a,p,policies)
            for _ in range(len(a.players[p].fleets)+1):
                order=select(p,'fleet')
                if order[0]=='none':break
                a.submit(p,'fleet',order,combat)
                if a.stop:break
            if a.stop:break
            for phase in ('faction','social','construction'):
                if phase=='social':
                    social(a,p,policies,combat);continue
                order=select(p,phase);a.submit(p,phase,order,combat)
                if a.stop:break
            if a.stop:break
        if a.stop:break
        a.closing()
    counts={}
    for e in a.log:
        if 'action' in e:counts[e['action']]=counts.get(e['action'],0)+1
    return dict(seed=seed,cycles=a.cycle,rotation=rotation,policy_rotation=policy_rotation,planner_depth=planner_depth,start=start,stop=a.stop,actions=counts,
        players=[dict(supply=s.supply,manpower=s.manpower,holdings=sum(w.owner==p for w in a.holdings),strength=sum(f.strength for f in s.fleets),deficits=s.deficits,deficit_entries=sum(v for k,v in s.counts.items() if k.startswith('deficit_'))) for p,s in enumerate(a.players)]),a.log

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--diagnostic',action='store_true');parser.add_argument('--balance',action='store_true');parser.add_argument('--seeds',type=int,default=4);parser.add_argument('--cycles',type=int,default=18);parser.add_argument('--out',default='shared-results');args=parser.parse_args()
    if args.balance:
        from readiness import require_ready
        require_ready()
    elif not args.diagnostic:raise SystemExit('Choose --diagnostic or validated --balance mode.')
    out=Path(args.out);out.mkdir(exist_ok=True);rows=[]
    for start in (6,20):
        for rotation in range(3):
            for seed in range(args.seeds):
                row,trace=run(seed,args.cycles,start,rotation);rows.append(row)
                (out/f'trace-{start}-{rotation}-{seed}.json').write_text(json.dumps(trace,indent=2))
        print('Starting resources',start,'finished',flush=True)
    (out/'trials.json').write_text(json.dumps(rows,indent=2))
    (out/'manifest.json').write_text(json.dumps(dict(engine_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),core_sha256=hashlib.sha256(Path('balance_sim.py').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path('Source_Rules.md').read_bytes()).hexdigest(),seeds=args.seeds,cycles=args.cycles,classification='integration experiments, not balance certification',limitations=['Legacy asymmetric synthetic fixture; prefer balance_experiment.py for controlled comparisons','Bounded heuristic/search policies do not model human Soulstorm skill','Provisional raid profile and B21 defensive-cost timing are retained','Personnel and future Sector mechanics are not numerical Subsector mechanics']),indent=2))
    print('Trials',len(rows),'stopped',sum(bool(r['stop']) for r in rows),flush=True)

if __name__=='__main__':main()
