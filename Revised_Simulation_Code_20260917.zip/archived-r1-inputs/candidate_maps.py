"""Seeded 2-4 holding generation, separate from combat and event RNG."""
import random
from sim_scenarios import from_spec
from proposal_checks_20260917 import SYSTEMS

def generated_fixture(traits=('siege','efficient','mobile'),initial_strength=5,minor_tier=2,seed=0):
 r=random.Random(seed);players=[];holdings=[]
 for p,trait in enumerate(traits):
  capital=-1
  if trait!='mobile':
   capital=len(holdings);holdings.append(dict(tier=4,defence=12,maximum=12,system=p,owner=p))
  players.append(dict(trait=trait,alignment='Independent',capital=capital,fleets=[dict(strength=12 if trait=='mobile' else initial_strength,maximum=12 if trait=='mobile' else 5,system=p,mobile=trait=='mobile')]))
 a=from_spec(dict(classification='synthetic test scenario',players=players,holdings=holdings))
 for p in range(3):a.add_minor([(2,4,4,p,False),(1,2,2,p,False)])
 prize_system=r.randrange(3,10);generation=[]
 for system in range(3,10):
  roll=r.randint(1,20);m,s,g,stations=SYSTEMS[roll-1]
  bodies=[(1,False)]*m+[(2,False)]*s+[(3,False)]*g+[(t,True) for t in stations]
  if system==prize_system:
   i=max((i for i,x in enumerate(bodies) if not x[1]),key=lambda i:bodies[i][0]);bodies[i]=(4,False)
  r.shuffle(bodies);ownership=r.randint(1,20);size=1 if ownership<=6 else 2 if ownership<=15 else 3
  for start in range(0,len(bodies),size):
   group=bodies[start:start+size]
   a.add_minor([(t,{1:2,2:4,3:8,4:12}[t],{1:2,2:4,3:8,4:12}[t],system,station) for t,station in group],prize=any(t==4 for t,_ in group))
  generation.append(dict(system=system,roll=roll,ownership=ownership,bodies=bodies))
 a.generation=dict(seed=seed,prize_system=prize_system,systems=generation)
 a.check();return a
