"""Frozen connected candidate study: 216 matched-geography and 216 generated-map games."""
import concurrent.futures,gzip,hashlib,json,shutil,time,traceback
from pathlib import Path
from bot_qualification import play
from integrated_balance_sample import specification
from sim_replay import inputs
from verify_bot_trace import verify
OUT=Path('revised-study')

def run(job):
 arm,n=job;folder=OUT/arm;folder.mkdir(exist_ok=True)
 path=folder/f'case-{n:03}.json'
 if path.exists():return json.loads(path.read_text())
 setup=specification(n);block=((n//3)%6)*3+n%3
 setup.update(stop_on_coalition=True)
 if arm=='generated':setup.update(generated_map=True,map_seed=7100+block)
 start=time.monotonic()
 row,trace=play(case=block,seed=1700+block,cycles=200,large=True,setup=setup)
 row.update(sample_id=n,arm=arm,focal_seat=n%3,elapsed_seconds=round(time.monotonic()-start,2))
 row['verified_orders']=verify(row,trace)
 row['censored']='one_major_coalition' not in row['milestones']
 row['combat_counts']={k:sum(e.get('combat')==k for e in trace['log']) for k in ('ground','naval','structure','third_party_raid')}
 row['fortification_repairs']=sum(e.get('action')=='fortification_repair' for e in trace['log'])
 row['build_profiles']={}
 for entry in trace['orders']:
  o=entry['order']
  if o[0]=='start':row['build_profiles'][o[1]]=row['build_profiles'].get(o[1],0)+1
 with gzip.open(folder/f'case-{n:03}.trace.json.gz','wt',encoding='utf-8') as f:json.dump(trace,f,separators=(',',':'))
 path.write_text(json.dumps(row,indent=2),encoding='utf-8')
 return row

def main():
 OUT.mkdir(exist_ok=True);fingerprint=inputs()
 for name in ['bot_qualification.py','verify_bot_trace.py','revised_study.py','candidate_tests.py','integrated_balance_sample.py']:
  fingerprint[name]=hashlib.sha256(Path(name).read_bytes()).hexdigest()
 manifest=dict(status='running',target_games=432,arms=['matched','generated'],maximum_cycles=200,inputs=fingerprint,
  design='Each arm: 12 focal traits x 6 strategies x 3 seats. 18 matched random blocks. Generated arm has 18 map seeds, shared across focal traits.',
  endpoint='First single surviving Major coalition; not necessarily all Minor holdings conquered.',
  limits=['AI combat, not human Soulstorm win rates','Bot estimates and routing updated with rules; difference is not an isolated rules-only causal effect','Early completion stops play; censored trials remain in results'])
 mp=OUT/'manifest.json'
 if mp.exists():assert json.loads(mp.read_text())['inputs']==fingerprint,'Do not mix candidate versions'
 pin=OUT/'inputs';pin.mkdir(exist_ok=True)
 for name in fingerprint:shutil.copy2(name,pin/name)
 mp.write_text(json.dumps(manifest,indent=2))
 start=time.monotonic();rows=[]
 jobs=[(arm,n) for n in range(216) for arm in ('matched','generated')]
 try:
  with concurrent.futures.ProcessPoolExecutor(max_workers=6) as pool:
   futures={pool.submit(run,job):job for job in jobs}
   for f in concurrent.futures.as_completed(futures):
    row=f.result();rows.append(row)
    (OUT/'results.json').write_text(json.dumps(rows,indent=2))
    print(f"Completed {len(rows)}/432: {row['arm']} {row['sample_id']}; Cycle {row['cycles']}; censored={row['censored']}; elapsed {round(time.monotonic()-start)}s",flush=True)
 except Exception:
  manifest.update(status='failed',error=traceback.format_exc(),completed=len(rows));mp.write_text(json.dumps(manifest,indent=2));raise
 assert inputs()=={k:v for k,v in fingerprint.items() if k in inputs()}
 manifest.update(status='complete',completed=len(rows),verified_orders=sum(r['verified_orders'] for r in rows),elapsed_seconds=round(time.monotonic()-start))
 mp.write_text(json.dumps(manifest,indent=2))
if __name__=='__main__':main()
