"""Player-facing setup matrix: no invented human outcomes."""
import json
from pathlib import Path
from battle_setup import BattleSide,setup
rows=[]
for label,tiers,fs,mult in [('ordinary Standard+Minor',[2,1],3,1),('ordinary Major+Standard+Minor',[3,2,1],7,1),('prize Capital',[4],12,2),('prize Capital+Standard+Minor',[4,2,1],18,2),('prize Capital+Major+Standard+Minor',[4,3,2,1],26,2)]:
 tier=max(tiers);pool=5*sum(tiers)*mult
 for resources in (20,40,60,80,100):
  for strength in (5,10,15,20):
   commitment=strength//5;incoming=commitment+1
   player=BattleSide(resources-tier,resources-commitment,strength,'Player')
   defender=BattleSide(pool-tier,pool-incoming,fs,'Minor')
   row=dict(scenario=label,starting_resources=resources,attacking_strength=strength,enemy_pool=pool,post_cost_player=dict(supply=player.supply,manpower=player.manpower),post_cost_enemy=dict(supply=defender.supply,manpower=defender.manpower))
   try:row['setup']=setup(player,defender)
   except ValueError as e:row['unresolved_setup']=str(e)
   rows.append(row)
Path('revised-study/player-setups.json').write_text(json.dumps(rows,indent=2))
print('Checked',len(rows),'player setups; unresolved existing scaling:',sum('unresolved_setup' in r for r in rows))
for r in rows:
 if r['starting_resources']==20 and r['attacking_strength']==5:print(r['scenario'],r.get('unresolved_setup',r.get('setup')))
