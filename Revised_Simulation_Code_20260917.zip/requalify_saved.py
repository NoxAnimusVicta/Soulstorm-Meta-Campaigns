"""Requalify saved successful games after the no-Capital-site crash fix."""
import concurrent.futures,gzip,json,hashlib
from pathlib import Path
from sim_replay import inputs
from verify_bot_trace import verify
ROOT=Path('revised-study')
def one(path):
 p=Path(path);row=json.loads(p.read_text());tracepath=p.with_name(p.stem+'.trace.json.gz')
 with gzip.open(tracepath,'rt',encoding='utf-8') as f:doc=json.load(f)
 count=verify(row,doc)
 row.setdefault('original_inputs',row['inputs']);row['inputs']=inputs();row['verified_orders']=count;row['requalified']='R2: no eligible Capital site permits idle; exact order/state replay unchanged'
 p.write_text(json.dumps(row,indent=2));return dict(arm=row['arm'],case=row['sample_id'],orders=count)
def main():
 paths=[str(p) for arm in ('matched','generated') for p in (ROOT/arm).glob('case-[0-9][0-9][0-9].json')]
 results=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=6) as pool:
  for row in pool.map(one,paths):
   results.append(row)
   if len(results)%12==0:print('Revalidated',len(results),'/',len(paths),flush=True)
 fingerprint=inputs()
 for name in ['bot_qualification.py','verify_bot_trace.py','revised_study.py','candidate_tests.py','integrated_balance_sample.py']:fingerprint[name]=hashlib.sha256(Path(name).read_bytes()).hexdigest()
 audit=dict(status='complete',games=len(results),orders=sum(r['orders'] for r in results),new_inputs=fingerprint,cases=results,previous_evidence='revised-study-v1-debug')
 (ROOT/'requalification.json').write_text(json.dumps(audit,indent=2))
 (ROOT/'manifest.json').write_text(json.dumps(dict(status='requalified_partial',inputs=fingerprint),indent=2))
 print('Requalification complete',len(results),flush=True)
if __name__=='__main__':main()
