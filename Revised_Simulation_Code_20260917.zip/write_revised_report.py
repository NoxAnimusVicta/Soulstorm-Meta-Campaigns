"""Publishable report builder. Refuses to label a partial sample complete."""
import json,statistics
from pathlib import Path
R=Path(__file__).parent;D=R/'revised-study'
def main():
 manifest=json.loads((D/'manifest.json').read_text());assert manifest['status']=='complete' and manifest['completed']==432
 data=json.loads((D/'analysis.json').read_text());audit=json.loads((D/'route-audit.json').read_text());assert len(audit)==36
 setups=json.loads((D/'player-setups.json').read_text());assert len(setups)==100
 a=data['arms'];diff=data['matched_restricted_duration_difference'];bombs=[b for r in audit for b in r['bombardments']]
 affordable=[b for b in bombs if b['ground_alternatives']];strong=[b for b in affordable if b['best_ground_chance']>=.65]
 text=['# Revised balance testing — 17 September 2026','',
 '**Complete: approved rules implemented in an isolated candidate; 432 campaigns recorded and replay-validated. This is a balance assessment, not certification that the package is balanced.**','',
 'The original simulator and historical evidence remain preserved. Dessica remains suspended at Cycle 21. Use the revised simulator download for this rules package; the old root engine is retained as a historical control.','',
 '## What was implemented','',
 'Holding construction capacity with free built-in Capital yards and the agreed shipyard/Consolidation exceptions; base effects retained during upgrades; transferred fleet constructions preserved on merges; Expand Fleet costs 1 Supply/1 Manpower; shared Minor support and reduced ordinary Minor starting strength; doubled prize-Minor support; divided resource contributions; assault breakthrough and Siege bonus; damage-priced bombardment; 2d6 naval combat with uncapped margin-based losses; revised Troop Transports, Fortification and Dread; random Planet Fall allocation; Storm Transit installations; and the d20 generator with 2–4 holdings and mean 3. No new fleet/system construction limits.','',
 'Fortification pays normal Defend costs, restores +2 extra defence and repairs one completed defensive construction Integrity only after the host reaches full defence. Repair ties use stable existing-project order. Dread discounts defensive Build/Upgrade to 3 Supply per stage and no longer penalises defensive resource returns. The named alignment-specific Storm Transit structures all use identical mechanics.','',
 '## Validation and correction','',
 f"227 regression checks and six additional interaction checks passed. Every campaign was replayed through public order validation: **{manifest['verified_orders']:,} orders** in this sample.",
 'A generated-map case exposed an empty-action crash when a Capital-less faction retained only stations. The corrected engine allows an idle Faction Action until it acquires an eligible planetary site; it does not permit a station Capital or bypass Establish New Capital priority. All 127 previously completed games reproduced exactly under the correction before reuse. First-version inputs and the requalification record are preserved. No failed case is counted as a completed game.','',
 '## Study design','',
 'Two arms of 216 games each: 12 focal traits × 6 strategies × 3 seats. The matched arm retains the historical geography and event-seed blocks. The generated arm uses 18 seeded maps, each shared across the 12 focal-trait variants. There are 18 blocks per arm, not 432 independent random replicates.','',
 'The endpoint is the first single surviving Major coalition, matching the previous competitive milestone. Games are followed to Cycle 200; unresolved games stay in the counts. This endpoint can precede conquest of remaining Minor holdings. Bots use revised combat estimates and compare attack routes; historical differences therefore reflect the rules package with adapted bots, not a rules-only causal experiment. No human Soulstorm victory or defeat is fabricated.','',
 '## Campaign duration','',
 '| Measure | Historical geography, revised rules | Generated maps, revised rules |','|---|---:|---:|']
 for label,key in [('Games','games'),('Completed by 200','completed'),('Still unresolved at 200','censored'),('Finished below Cycle 50','below50'),('Finished in Cycles 50–100','within50_100'),('Finished after Cycle 100','above100'),('Median among completed games','median_completed'),('Mean among completed games','mean_completed'),('Full control also reached at stopping point','full_control_at_stop'),('Average initial holdings','initial_holdings_mean')]:text.append(f"| {label} | {a['matched'][key]} | {a['generated'][key]} |")
 text+=['',f"On the matched geography, the paired difference in duration restricted to the first 100 Cycles is **{diff['mean']:+.2f} Cycles** relative to the historical sample. The block-bootstrap 95% interval is {diff.get('block_bootstrap_95pct')}. This uses the same 100-Cycle observation window so historical unfinished cases are not discarded.",'',
 '## Attack choices and resources','', '| Measure | Matched geography | Generated maps |','|---|---:|---:|']
 for action in ('ground','ground_mobile','naval','bombard_shared','structure_assault','ration'):
  text.append(f"| {action} orders | {a['matched']['actions'].get(action,0)} | {a['generated']['actions'].get(action,0)} |")
 for label,key in [('Games using bombardment','bombard_games'),('Fortification bonus repairs triggered','fortification_repairs')]:text.append(f"| {label} | {a['matched'][key]} | {a['generated'][key]} |")
 for label,key in [('Mean Supply, surviving original factions','supply_mean'),('Mean Manpower, surviving original factions','manpower_mean'),('Supply locked, % of surviving faction-Cycles','supply_locked_pct'),('Manpower locked, % of surviving faction-Cycles','manpower_locked_pct')]:text.append(f"| {label} | {a['matched']['resources'][key]} | {a['generated']['resources'][key]} |")
 text+=['',f"A prespecified 36-game replay audit found **{len(bombs)} bombardments**. **{len(affordable)}** had at least one affordable Ground Assault against the same holding at that moment; **{len(strong)}** had an affordable alternative with at least 65% AI victory probability. These counts test whether bombardment is merely a last legal option. They do not establish optimality or substitute for human battle performance.",'',
 '## Trait results','',
 'The entries below count the focal original faction surviving in the winning coalition. Each cell has only 18 cases. Unresolved games are not counted as wins; coalition descendants do not make an eliminated original faction a survivor. Treat differences as investigation signals, not a definitive trait ranking.','',
 '| Focal trait | Matched wins / 18 | Generated wins / 18 |','|---|---:|---:|']
 for trait in a['matched']['traits']:
  text.append(f"| {trait} | {a['matched']['traits'][trait]['focal_surviving_winners']} | {a['generated']['traits'][trait]['focal_surviving_winners']} |")
 text+=['','## Player-facing formation audit','',
 f"The separate 100-setup stress matrix found {sum('unresolved_setup' in x for x in setups)} setups where the inherited formation-scaling rule cannot preserve the difference while keeping each side between one and four formations. This is a deliberately chosen stress matrix, not the frequency of that problem in normal play.",
 'Example: a player starting at 20 Supply/20 Manpower attacks with 5 strength. Ordinary Standard+Minor opposition gives Hard, 1 versus 1; a lone prize Capital gives Harder, 1 versus 2. A prize Capital+Standard+Minor gives a 1-versus-5 formation calculation that the existing scaling rule cannot represent. High-resource oversized player armies can break the rule in the other direction too. No formations were silently removed to make those setups pass. This needs a player-facing rules decision before calling the candidate ready for unrestricted Soulstorm play.','',
 '## Evidence and reproduction','',
 'Download the revised simulator plus both evidence archives. Extract them into the same folder. `python revised_study.py` resumes or regenerates the 432-case study, refusing mixed fingerprints. `python analyse_revised.py`, `python audit_revised_routes.py` and `python audit_player_setups.py` reproduce the summaries and audits. Analysis of the historical paired difference also requires the earlier integrated-balance-20260917 results in the parent directory or the bundled historical-baseline folder.','',
 'Read `revised-study/manifest.json` for exact inputs and completion status, `requalification.json` for the crash-fix replay audit, and the per-game compressed traces for orders, events and outcomes. Human outcomes remain external inputs. Sector work and the mod project remain tabled.']
 (R.parent/'Revised_Balance_Testing_2026-09-17.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
 data['route_audit_summary']=dict(games=len(audit),bombardments=len(bombs),with_affordable_ground=len(affordable),with_ground_chance_at_least_65pct=len(strong))
 data['player_setup_stress_failures']=sum('unresolved_setup' in x for x in setups)
 (R.parent/'Revised_Balance_Results_20260917.json').write_text(json.dumps(data,indent=2))
 print('Final report generated only from the complete validated sample.')
if __name__=='__main__':main()
