"""Additional interaction checks against the frozen candidate engine."""
import unittest,random
from sim_scenarios import campaign_fixture
from balance_sim import Project,Fleet
from construction_rules import construct,magnitude

class Edges(unittest.TestCase):
 def test_upgrading_flagship_does_not_grant_strength_early(self):
  a=campaign_fixture();s=a.players[0];s.supply=100;s.fleets[0].maximum=s.fleets[0].strength=10
  p=Project('flagship',('fleet',0),5,5,True);p.granted_capacity=5;p.permanent_integrity=5;s.projects=[p]
  a.act(0,('upgrade',0),random.Random(1));self.assertEqual(s.fleets[0].maximum,10)
  for _ in range(4):a.act(0,('build',0),random.Random(1))
  self.assertEqual(s.fleets[0].maximum,15);s.hit_fleet(0,1);self.assertEqual(s.fleets[0].maximum,15)
 def test_transit_protects_mobile_and_attached_integrity(self):
  a=campaign_fixture();s=a.players[2];s.projects=[Project('forge',-1,5,5,True),Project('storm_transit',('system',2),5,5,True)]
  class Storm:
   def randint(self,*args):return 1
  a.opening(Storm());self.assertEqual(s.fleets[0].strength,12);self.assertEqual(s.projects[0].integrity,5)
  a.players[0].fleets[0].system=2;a.alliances.add(frozenset((0,2)))
  self.assertFalse(a.storm_protected(0,2));a.transit_consents.add((2,0));self.assertTrue(a.storm_protected(0,2))
 def test_fortification_does_not_finish_unbuilt_structure(self):
  a=campaign_fixture(('fortification','efficient','mobile'));s=a.players[0];h=a.capitals[0];s.projects=[Project('bunker',h,2,3,False)];a.holdings[h].defence=8
  a.act(0,('defend',h),random.Random(0));self.assertEqual(s.projects[0].integrity,2)
 def test_transport_cannot_create_manpower(self):
  a=campaign_fixture();s=a.players[0];s.projects=[Project('troop_transport',('fleet',0),3,3,True)]
  i=next(i for i,w in enumerate(a.holdings) if w.owner==3 and w.tier==1)
  a.act(0,('ground',(0,),i),random.Random(0),(20,1));self.assertEqual(s.manpower,20)
 def test_bombard_cost_after_cannons(self):
  a=campaign_fixture();s=a.players[0];s.supply=7;s.fleets=[Fleet(15,15,0)];q=3;i=next(i for i,w in enumerate(a.holdings) if w.owner==q and w.tier==2)
  for f in a.players[q].fleets:f.strength=0
  a.players[q].projects=[Project('orbital_cannons',i,3,3,True)]
  self.assertEqual(a.bombard_cost(0,(0,),i),6);self.assertIn(('bombard_shared',(0,),i),a.actions(0,'fleet'))
  a.submit(0,'fleet',('bombard_shared',(0,),i),random.Random(0));self.assertEqual((s.supply,s.fleets[0].strength,a.holdings[i].defence),(1,14,2))
 def test_upgrade_regeneration_stays_baseline_until_complete(self):
  a=campaign_fixture();s=a.players[0];h=a.capitals[0];s.projects=[Project('automated_defences',h,4,6,False,True)];a.holdings[h].defence=8;a.closing();self.assertEqual(a.holdings[h].defence,9)

if __name__=='__main__':unittest.main(verbosity=2)
