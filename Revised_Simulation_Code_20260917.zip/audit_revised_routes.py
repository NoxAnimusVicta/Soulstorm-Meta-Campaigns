"""Replay a prespecified mixed-trait audit subset and inspect bombardment alternatives."""
import gzip,json,random
from pathlib import Path
from collections import Counter
from sim_replay import restore,decode,digest
from bot_control import coordinate,social
from verify_bot_trace import tuples
from operational_bots import odds
ROOT=Path('revised-study')

def audit(row,doc):
 a=restore(doc['initial']);rng=random.Random(1000+row['case']+row['seed']*10000)
 commands=iter(doc['orders']);policies=row['policies'];bombards=[];discount=Counter()
 for cycle in range(1,row['cycles']+1):
  a.opening(random.Random(100000+row['case']*100+a.cycle+row['seed']*1000000))
  for p in a.turns():
   a.begin_turn(p);coordinate(a,p,policies)
   for phase in ('fleet','faction','social','construction'):
    if phase=='social':social(a,p,policies,rng);continue
    for _ in range(sum(len(s.fleets) for s in a.players)+1 if phase=='fleet' else 1):
     entry=next(commands);memory=decode(entry['bot_memory'])
     for field,key in [('bot_plans','plans'),('diagnostic_targets','diagnostic')]:
      if memory[key] or hasattr(a,field):setattr(a,field,memory[key])
     order=tuples(entry['order']);s=a.players[p]
     if order[0]=='bombard_shared':
      alternatives=[o for o in a.actions(p,'fleet',search=True) if o[0]=='ground' and o[2]==order[2]]
      chances=[odds(a,p,o) for o in alternatives]
      bombards.append(dict(cycle=cycle,player=p,trait=s.trait,policy=policies[p] if p<3 else 'summoned',supply=s.supply,manpower=s.manpower,defence=a.holdings[order[2]].defence,
       cost=a.bombard_cost(p,order[1],order[2]),ground_alternatives=len(alternatives),best_ground_chance=max(chances,default=None)))
     if order[0] in ('start','build','upgrade'):
      from construction_rules import cost
      name=order[1] if order[0]=='start' else s.projects[order[1]].profile
      discount[s.trait]+=5-cost(s,name)
     a.submit(p,phase,order,rng)
     if order[0]=='none':break
  a.closing();a.check()
 assert digest(a)==row['final']
 return dict(arm=row['arm'],sample_id=row['sample_id'],bombardments=bombards,construction_savings=dict(discount))

def main():
 rows=json.loads((ROOT/'results.json').read_text());chosen={18*(block%12)+block for block in range(18)}
 out=[]
 for row in rows:
  if row['sample_id'] not in chosen:continue
  with gzip.open(ROOT/row['arm']/f"case-{row['sample_id']:03}.trace.json.gz",'rt',encoding='utf-8') as f:trace=json.load(f)
  out.append(audit(row,trace));print(row['arm'],row['sample_id'],len(out[-1]['bombardments']),flush=True)
 (ROOT/'route-audit.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
