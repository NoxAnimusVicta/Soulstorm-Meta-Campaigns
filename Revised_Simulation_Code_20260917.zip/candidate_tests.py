import unittest,random,math
from shared_sim import Arena
from sim_scenarios import campaign_fixture
from balance_sim import Project,Fleet,fleet_losses
from construction_rules import legal_construction,cost,magnitude,construct
from candidate_maps import generated_fixture
from operational_bots import odds
from sim_replay import snapshot,restore

class RevisedRules(unittest.TestCase):
 def fresh(self,trait='efficient'):
  a=campaign_fixture((trait,'efficient','mobile'));a.cycle=1;a.begin_turn(0);return a
 def test_station_only_survivor_waits_for_valid_capital(self):
  a=self.fresh();a.capitals[0]=None;a.holdings[0].station=True
  self.assertEqual(a.actions(0,'faction'),[('none',)])
  a.submit(0,'faction',('none',),random.Random(0));self.assertEqual(a.players[0].supply,20)
  self.assertIsNone(a.capitals[0])

 def test_personnel(self):
  a=self.fresh();s=a.players[0];s.fleets[0].strength=3;a.act(0,('expand',0),random.Random(1));self.assertEqual((s.supply,s.manpower,s.fleets[0].strength),(19,19,5))
 def test_no_last_point(self):
  a=self.fresh();s=a.players[0];s.fleets[0].strength=3;s.manpower=1;self.assertNotIn(('expand',0),a.actions(0,'fleet'))
 def test_minor_pool(self):
  a=self.fresh();i=next(i for i,w in enumerate(a.holdings) if w.owner==3);self.assertEqual(a.minor_resources(i),(15,15));a.holdings[i].defence=1;self.assertEqual(a.minor_resources(i),(15,15));self.assertEqual(a.strength(3,0),3)
 def test_prize(self):
  a=self.fresh();p=a.add_minor([(4,12,12,4,False),(2,4,4,4,False),(1,2,2,4,False)]);i=len(a.holdings)-3;self.assertEqual(a.minor_resources(i),(70,70));self.assertEqual(a.strength(p,4),18);a.holdings[i].owner=0;self.assertEqual(a.minor_resources(i+1),(30,30))
 def test_upgrade_income(self):
  a=self.fresh();s=a.players[0];host=a.capitals[0];s.projects=[Project('forge',host,5,5,True)];base=s.income()[0];construct(s,('upgrade',0));self.assertEqual(s.income()[0],base);s.projects[0].integrity=4;self.assertEqual(s.income()[0],base-5);s.projects[0].integrity=10;s.projects[0].completed=True;self.assertEqual(s.income()[0],base+5)
 def test_upgrade_magnitude(self):
  a=self.fresh();s=a.players[0];s.projects=[Project('bunker',0,4,6,False,True)];self.assertEqual(magnitude(s,0,'bunker',4),4);s.projects[0].integrity=6;s.projects[0].completed=True;self.assertEqual(magnitude(s,0,'bunker',4),8)
 def test_holding_slot_and_merge(self):
  a=self.fresh();s=a.players[0];s.projects=[Project('forge',a.capitals[0],5,5,True)];orders=a.actions(0,'construction');self.assertNotIn(('start','academy',a.capitals[0]),orders);self.assertNotIn(('start','shipyard',a.capitals[0]),orders)
  s.fleets.append(Fleet(3,5,0));s.projects.extend([Project('escort',('fleet',0),3,3,True),Project('troop_transport',('fleet',1),3,3,True)]);a.act(0,('merge',0,1),random.Random(2));self.assertEqual(s.projects[-1].host,('fleet',0));self.assertFalse(s.fleets[1].used)
 def test_shipyard_line(self):
  a=self.fresh();s=a.players[0];host=a.capitals[0];self.assertIn(('start','grand_shipyard',host),a.actions(0,'construction'));s.projects=[Project('grand_shipyard',host,5,5,True)];self.assertNotIn(('start','forge',host),a.actions(0,'construction'))
 def test_dread(self):
  a=self.fresh('dread');s=a.players[0];self.assertEqual(cost(s,'bunker'),3);self.assertEqual(cost(s,'forge'),5);construct(s,('start','bunker',a.capitals[0]));self.assertEqual(s.supply,17)
 def test_fortification(self):
  a=self.fresh('fortification');s=a.players[0];h=a.capitals[0];a.holdings[h].defence=6;s.projects=[Project('bunker',h,2,3,True)];a.act(0,('defend',h),random.Random(1));self.assertEqual((s.supply,s.manpower,a.holdings[h].defence,s.projects[0].integrity),(16,16,12,3))
 def test_ground(self):
  a=self.fresh();i=next(i for i,w in enumerate(a.holdings) if w.owner==3 and w.tier==2);a.act(0,('ground',(0,),i),random.Random(1),(20,1));self.assertEqual(a.holdings[i].defence,2);row=next(r for r in a.log if r.get('combat')=='ground');self.assertEqual(row['totals'],[31,8]);self.assertEqual(a.players[0].manpower,19)
 def test_siege(self):
  a=self.fresh('siege');i=next(i for i,w in enumerate(a.holdings) if w.owner==3 and w.tier==2);a.holdings[i].defended=True;a.act(0,('ground',(0,),i),random.Random(1),(20,1));self.assertEqual(a.holdings[i].defence,1)
 def test_bombard(self):
  a=self.fresh();i=next(i for i,w in enumerate(a.holdings) if w.owner==3 and w.tier==2)
  for f in a.players[3].fleets:f.strength=0
  a.act(0,('bombard_shared',(0,),i),random.Random(1));self.assertEqual(a.players[0].supply,15);self.assertEqual(a.holdings[i].defence,3);self.assertEqual(a.players[0].manpower,20)
 def test_naval(self):
  self.assertEqual([fleet_losses(x) for x in (1,3,4,16,100)],[1,1,2,6,34]);a=self.fresh();a.players[3].fleets=[Fleet(5,5,0)];chance=odds(a,0,('naval',(0,),0,3));self.assertAlmostEqual(chance,435/1296)
  a.act(0,('naval',(0,),0,3),random.Random(5));row=next(r for r in a.log if r.get('combat')=='naval');self.assertTrue(all(2<=v<=12 for v in row['rolls']))
 def test_storm(self):
  a=self.fresh();s=a.players[0];s.projects=[Project('storm_transit',('system',0),5,5,True)]
  class Storm:
   def randint(self,*args):return 1
  a.opening(Storm());self.assertEqual(s.fleets[0].strength,5);self.assertIn(('move',0,1),a.actions(0,'fleet'));self.assertEqual(a.players[1].fleets[0].strength,4)
 def test_maps(self):
  for seed in range(20):
   a=generated_fixture(seed=seed);self.assertEqual(len(a.systems),10);self.assertEqual(sum(getattr(s,'prize',False) for s in a.players),1)
   for k in range(3,10):self.assertIn(sum(w.system==k for w in a.holdings),(2,3,4))
   self.assertEqual(snapshot(a),snapshot(restore(snapshot(a))))

if __name__=='__main__':unittest.main(verbosity=2)
