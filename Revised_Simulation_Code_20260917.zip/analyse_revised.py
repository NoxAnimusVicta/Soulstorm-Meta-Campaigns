"""Summarise frozen revised study; historical controls are never overwritten."""
import gzip,json,statistics,random
from pathlib import Path
from collections import Counter,defaultdict
from sim_replay import restore
ROOT=Path(__file__).parent
STUDY=ROOT/'revised-study'
def mean(xs):return round(statistics.mean(xs),3) if xs else None

def arm_stats(rows):
 durations=[r['milestones']['one_major_coalition'] for r in rows if not r['censored']]
 actions=Counter();builds=Counter();traits=defaultdict(list);resource=Counter();fort=0;holding_counts=[];bombard_games=0
 for r in rows:
  for x in r['actions']:actions[x['action']]+=x['count']
  bombard_games+=any(x['action']=='bombard_shared' and x['count'] for x in r['actions'])
  builds.update(r['build_profiles']);fort+=r['fortification_repairs'];traits[r['traits'][r['focal_seat']]].append(r)
  path=STUDY/r['arm']/f"case-{r['sample_id']:03}.trace.json.gz"
  with gzip.open(path,'rt',encoding='utf-8') as f:trace=json.load(f)
  holding_counts.append(len(restore(trace['initial']).holdings))
  for h in trace['history']:
   for p in h['players'][:3]:
    if p['eliminated']:continue
    resource['faction_cycles']+=1;resource['supply_total']+=p['supply'];resource['manpower_total']+=p['manpower']
    for key in ('supply','manpower'):
     resource[key+'_locked']+=key in p['deficits'];resource[key+'_low']+=p[key]<=5
 return dict(games=len(rows),completed=len(durations),censored=len(rows)-len(durations),mean_completed=mean(durations),median_completed=statistics.median(durations) if durations else None,
  minimum=min(durations) if durations else None,maximum=max(durations) if durations else None,
  below50=sum(x<50 for x in durations),within50_100=sum(50<=x<=100 for x in durations),above100=sum(x>100 for x in durations),
  restricted_mean100=mean([min(100,r['milestones'].get('one_major_coalition',200)) for r in rows]),
  full_control_at_stop=sum('all_holdings_and_mobile_capitals' in r['milestones'] for r in rows),
  actions=dict(actions),builds=dict(builds),fortification_repairs=fort,bombard_games=bombard_games,initial_holdings_mean=mean(holding_counts),
  resources={**dict(resource),**{key+'_mean':round(resource[key+'_total']/max(1,resource['faction_cycles']),2) for key in ('supply','manpower')},**{key+'_locked_pct':round(100*resource[key+'_locked']/max(1,resource['faction_cycles']),2) for key in ('supply','manpower')}},
  traits={t:dict(games=len(rs),focal_surviving_winners=sum(not r['censored'] and not r['players'][r['focal_seat']]['eliminated'] for r in rs),unresolved=sum(r['censored'] for r in rs),median_duration=statistics.median([r['cycles'] for r in rs])) for t,rs in traits.items()})

def main():
 rows=json.loads((STUDY/'results.json').read_text());manifest=json.loads((STUDY/'manifest.json').read_text())
 result=dict(status=manifest['status'],games=len(rows),arms={arm:arm_stats([r for r in rows if r['arm']==arm]) for arm in ('matched','generated')})
 baseline=ROOT.parent/'integrated-balance-20260917'/'results.json'
 if not baseline.exists():baseline=ROOT/'historical-baseline'/'results.json'
 base=json.loads(baseline.read_text());lookup={r['sample_id']:r for r in base}
 blocks=defaultdict(list)
 for r in rows:
  if r['arm']!='matched':continue
  b=lookup[r['sample_id']];blocks[r['case']].append(min(100,r['milestones'].get('one_major_coalition',200))-b['milestones'].get('one_major_coalition',100))
 result['matched_restricted_duration_difference']=dict(mean=mean([v for block in blocks.values() for v in block]),blocks=len(blocks))
 if len(blocks)==18 and all(len(x)==12 for x in blocks.values()):
  rng=random.Random(1791);values=[statistics.mean(v) for v in blocks.values()]
  boot=sorted(statistics.mean(rng.choices(values,k=18)) for _ in range(4000))
  result['matched_restricted_duration_difference']['block_bootstrap_95pct']=[round(boot[100],2),round(boot[3899],2)]
 (STUDY/'analysis.json').write_text(json.dumps(result,indent=2))
 print(json.dumps({k:v for k,v in result.items() if k!='arms'},indent=2))
 for k,s in result['arms'].items():print(k,json.dumps({x:y for x,y in s.items() if x not in ('actions','builds','traits','resources')}))
if __name__=='__main__':main()
