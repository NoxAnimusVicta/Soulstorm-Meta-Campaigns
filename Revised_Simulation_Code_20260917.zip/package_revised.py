"""Bundle the completed revised simulator and split evidence below GitHub upload limits."""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).parent;OUT=R.parent;D=R/'revised-study'
def pack(path,items,readme):
 hashes={}
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for src,name in items:
   z.write(src,name);hashes[name]=hashlib.sha256(src.read_bytes()).hexdigest()
  z.writestr('README.txt',readme)
  z.writestr('FILE_HASHES.json',json.dumps(hashes,indent=2))
 assert path.stat().st_size<24*1024*1024,(path,path.stat().st_size)
 print(path.name,path.stat().st_size,flush=True)
def main():
 manifest=json.loads((D/'manifest.json').read_text());assert manifest['status']=='complete' and manifest['completed']==432
 names=set(manifest['inputs'])|{'readiness.py','analyse_revised.py','audit_revised_routes.py','audit_player_setups.py','write_revised_report.py','package_revised.py','requalify_saved.py','candidate_edge_checks.py'}
 names.update(p.name for p in R.glob('*tests.py'))
 items=[(R/n,n) for n in sorted(names)]
 # Historical rows allow paired summary reproduction without a separate 15 MB archive.
 items.append((OUT/'integrated-balance-20260917'/'results.json','historical-baseline/results.json'))
 items.append((OUT/'Revised_Balance_Testing_2026-09-17.md','Revised_Balance_Testing_2026-09-17.md'))
 items.extend((p,'archived-r1-inputs/'+p.name) for p in (R/'revised-study-v1-debug'/'inputs').iterdir() if p.is_file())
 pack(OUT/'Revised_Simulation_Code_20260917.zip',items,
  'Revised candidate R2, 17 September 2026. Extract both evidence archives here too. Run python -m unittest discover -p "*tests.py" and python candidate_edge_checks.py. Run python revised_study.py to resume/reproduce the frozen 432-case study. Run python analyse_revised.py and the two audit scripts for summaries. The historical baseline result rows are under historical-baseline/. Original R1 inputs are archived for provenance; use the root R2 engine. No human Soulstorm outcomes are generated.\n')
 common=[p for p in D.iterdir() if p.is_file() and p.suffix=='.json']
 for arm in ('matched','generated'):
  files=[(p,'revised-study/'+p.name) for p in common]
  files.extend((p,'revised-study/errors/'+p.name) for p in (D/'errors').glob('*.json'))
  files.extend((p,'revised-study/'+arm+'/'+p.name) for p in (D/arm).iterdir() if p.is_file())
  pack(OUT/f'Revised_{arm.title()}_Evidence_20260917.zip',files,
   f'Completed {arm} arm: 216 games, with exact order traces. Extract into the revised simulator folder alongside the other arm. Shared manifests and summary files are identical in both archives. Campaigns stop at the first single surviving Major coalition or at Cycle 200; remaining Minor holdings may still exist.\n')
if __name__=='__main__':main()
