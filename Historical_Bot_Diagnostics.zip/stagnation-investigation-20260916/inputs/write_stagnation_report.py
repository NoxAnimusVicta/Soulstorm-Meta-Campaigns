"""Measured diagnostic findings; never changes campaign balance or readiness."""
import json,hashlib
from pathlib import Path
from sim_replay import restore,digest

root=Path(__file__).resolve().parent;folder=root/'stagnation-investigation-20260916'
rows=[]
for path in sorted(folder.glob('case-*.json')):
 d=json.loads(path.read_text());a=restore(d['final']);assert a.cycle==100 and not a.stop
 events=[x['cycle'] for x in d['log'] if x.get('action')=='event'];assert events==list(range(1,101))
 p=d['focal'];mode=d.get('mode','both');seed=d['seed_offset']
 rows.append(dict(case=d['case'],mode=mode,seed=seed,holdings=d['history'][-1]['holdings'][p],eliminated=p in a.eliminated,first_capture=next((h['cycle'] for h in d['history'] if h['holdings'][p]>1),None),ground=sum(x['order'][0]=='ground' and x['player']==p for x in d['commands']),naval=sum(x['order'][0]=='naval' and x['player']==p for x in d['commands']),bombard=sum(x['order'][0]=='bombard_shared' and x['player']==p for x in d['commands']),file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
lines=['# Stagnation investigation — 16 September 2026','',
'**Finding: the stalled games are not sufficient evidence of a rules deadlock. A separate diagnostic controller expanded successfully under the same rules where the original bot stalled.** Coordinating an operational target with resource preparation mattered more than simply choosing more attacks. The diagnostic is not a replacement for the full strategic AI and is not a balance certification.','',
'## What was wrong with the original decision process?','',
'1. **It values assets more clearly than a funded operation.** The immediate utility gives every point of Fleet Strength continuing linear value, while resource stocks receive diminishing square-root value. It includes upkeep buffers but no persistent offensive budget or siege objective. Repeated fleet creation can consume the Faction Actions needed for resupply and increase later upkeep. This is an implementation preference, not a campaign rule.',
'2. **It lacks a coordinated multi-turn target.** Most original decisions optimise the next action or a short rollout. They do not commit to clearing a particular orbit and funding the subsequent landing. Moving toward immediate local strength bonuses can scatter fleets among rival systems instead.',
'3. **Diplomacy can preserve contested deadlocks.** At saved Case 1/Cycle 40, the focal faction had 20 strength at home, while a rival had 10 there. Their ceasefire was still active. The rival could not be attacked and still prevented uncontested bombardment. All three majors had fleets in rival systems, and there were no legal uncontested bombardments. This is a strategically costly combination of legal choices; it is not a reason to change ceasefire or void-control rules.',
'4. **Some avoided assaults really were hopeless.** The best-ranked ground option at that snapshot had equal-dice totals 43 versus89. The d20 difference cannot bridge 46. Minor-world resources of 40 Supply and 40 Manpower at full defence match the source rules. Forcing aggression without preparation would conceal the problem rather than fix it.','',
'## Controlled diagnostic','',
'I added a separate challenger with a persistent target, exact two-d20 win-probability checks, a clear-orbit/soften/land action sequence, and an explicit fifteen-capacity force budget before returning Faction Actions to resupply or recruitment. The force budget and 65% attack threshold are diagnostic settings, not rules or demonstrated optimal values. Construction decisions and opponents use the original policies; the combined challenger also keeps original diplomacy.',
'','Each run starts from the exact saved opening, follows the same 100-Cycle event sequence, and changes only one focal controller. Additional combat-seed offsets test sensitivity. Once actions differ, random draws can be consumed differently, so this is common initial randomness, not identical battle outcomes.','',
'| Case | Combat seed offset | Controller change | Focal holdings at 100 | First gained holding | Eliminated |','|---|---:|---|---:|---|---|',
'| 1 | 0 | Original saved baseline | 1 | None | No |',
'| 5 | 0 | Original saved baseline | 1 | None | No |']
labels={'both':'Fleet plan + funded force budget','fleet':'Fleet plan only','faction':'Force budget/resupply only','no_pacts':'Original bot, declines ceasefires','baseline':'Original bot'}
for r in sorted(rows,key=lambda r:(r['case'],r['seed'],r['mode'])):
 lines.append(f"| {r['case']} | {r['seed']} | {labels[r['mode']]} | {r['holdings']} | {r['first_capture'] or 'None'} | {'Yes' if r['eliminated'] else 'No'} |")
lines+=['','In the original Case 1 seed, fleet tactics alone and refusing ceasefires alone both led to elimination. Resource preparation alone gained no territory. The combined approach gained territory. This supports coordinated preparation and operations; it does not support blindly increasing aggression or removing diplomacy.',
'','The initial combined Case 1 and Case 5 runs did not actually use bombardment: preparation made direct assaults viable instead. The challenger can bombard, but the observed gains must not be attributed to bombardment. This is why inspecting actual orders matters.','',
'## Validation and limits','',
f'- {len(rows)} new full 100-Cycle diagnostic runs saved with complete orders, history, combat logs, initial/final snapshots, controller and engine hashes. The report checks all 100 event openings and final-state validity.',
'- 174 regression tests passed: the existing 170 plus checks that probability probes leave live state untouched, the diagnostic rebuilds after losing its force, preserves operational resources once its force budget is met, and retains its target.',
'- The extra controller remains isolated in `siege_diagnostic.py`; production rules and the existing production bot were not changed during this investigation. No source-rule rebalance or campaign turn was applied.',
'- These are a small number of synthetic cases and short diagnostic policies. The force budget is fixed, repair/retreat planning remains limited, and resource hoarding at the 100 cap can occur. Do not promote this controller as expert play or a completed replacement AI.',
'- The user’s desired average duration remains 50–100 Cycles with natural variation and shorter outliers. These tests diagnose progress, not the duration distribution. Final holdings at 100 do not imply the campaign ended then; the exact campaign-ending condition still needs confirmation.','',
'## Next implementation work justified by this evidence','',
'Give production strategies explicit target selection, a funded operational plan, and coordination between fleet, faction and construction choices. Make force budgets depend on threats, holdings, upkeep and intended operations rather than the diagnostic fixed value. Evaluate ceasefires against the operation they would prevent. Preserve the ability to retreat, recover and decline an unwinnable attack. Then rerun full-duration, varied-opponent qualification against this independent challenger and the historical baselines.','',
'Readiness remains **not qualified for balance conclusions**. These findings identify a bot-development problem before changing the game economy.','',
'Evidence: `stagnation-investigation-20260916/`; reproducible driver: `investigate_stagnation.py`; controller: `siege_diagnostic.py`; tests: `siege_diagnostic_tests.py`.','']
(root/'Stagnation_Investigation_Report.md').write_text('\n'.join(lines),encoding='utf-8')
(folder/'summary.json').write_text(json.dumps(dict(classification='bot diagnostic; not balance conclusions',runs=rows),indent=2))
print('Wrote investigation report for',len(rows),'completed runs')
