"""Controlled diagnostic: same saved opening; replace only one bot controller."""
import json,random,hashlib
from pathlib import Path
from collections import Counter
from sim_replay import restore,snapshot,digest,inputs
from shared_sim import choose,policy_for
from bot_control import coordinate,social
from siege_diagnostic import SiegeDiagnostic

root=Path(__file__).resolve().parent;out=root/'stagnation-investigation-20260916';out.mkdir(exist_ok=True)
def run(case,focal,seed_offset=0,mode='both'):
 source=root/'validation-release-20260916/hundred-cycle-results'/f'trace-{case}.json'
 doc=json.loads(source.read_text());a=restore(doc['initial']);policies=a.defender_policies
 rng=random.Random(1000+case+seed_offset);bot=SiegeDiagnostic();decision=0;history=[];commands=[]
 if mode=='no_pacts':
  import bot_control
  original=bot_control.accepts
  bot_control.accepts=lambda arena,recipient,sender,policies:False if recipient==focal else original(arena,recipient,sender,policies)
 for cycle in range(1,101):
  a.opening(random.Random(100000+case*100+a.cycle))
  for p in a.turns():
   a.begin_turn(p);coordinate(a,p,policies)
   for phase in ('fleet','faction','social','construction'):
    if phase=='social':social(a,p,policies,rng);continue
    for _ in range(sum(len(s.fleets) for s in a.players)+1 if phase=='fleet' else 1):
     policy=policy_for(a,p,policies)
     replace=p==focal and (mode=='both' or mode==phase)
     order=bot.select(a,p,phase,policy,decision) if replace else choose(a,p,phase,policy,decision)
     a.submit(p,phase,order,rng);decision+=1
     commands.append(dict(cycle=cycle,player=p,phase=phase,order=order,after=digest(a)))
     if order[0]=='none':break
  a.closing();a.check()
  history.append(dict(cycle=cycle,holdings=[sum(w.owner==p for w in a.holdings) for p in range(3)],eliminated=list(a.eliminated),focal_supply=a.players[focal].supply,focal_manpower=a.players[focal].manpower))
  if cycle%25==0:print('case',case,'focal',focal,'cycle',cycle,flush=True)
 counts=Counter(r.get('action',r.get('combat','unknown')) for r in a.log if r.get('player',r.get('attacker'))==focal)
 result=dict(case=case,focal=focal,mode=mode,cycles=100,inputs=inputs(),controller_sha256=hashlib.sha256((root/'siege_diagnostic.py').read_bytes()).hexdigest(),seed_offset=seed_offset,actions=dict(counts),history=history,final=snapshot(a),commands=commands,log=a.log,initial=doc['initial'])
 (out/f'case-{case}-focal-{focal}-{mode}-seed-{seed_offset}.json').write_text(json.dumps(result,indent=2))
 print('Finished',case,focal,'holdings',history[-1]['holdings'],flush=True)

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--case',type=int,required=True);ap.add_argument('--focal',type=int,default=0);ap.add_argument('--mode',choices=['both','fleet','faction','no_pacts','baseline'],default='both');ap.add_argument('--seed-offset',type=int,default=0);args=ap.parse_args();run(args.case,args.focal,seed_offset=args.seed_offset,mode=args.mode)
